var mysql =require('mysql');
var sql = require('../config/sql.js');
var connection = require('../config/database');
var connect = mysql.createConnection(connection.dbconfig)
	connect.connect(function(err){
	if(!err)
	console.log("done connection in show");
	else
	console.log("error in connection");
	});
	exports.getmoviedrop=function(callback){
		var query="SELECT movie_id,movie_name from movie;";
		sql.executeSql(query, function (data, err) {
								if (err) {
																callback(err, null);
								}
							 else {
																callback(null, data);
								}
							});
	}

exports.getshowtimedrop=function(callback){
	var query="SELECT show_id,showtime from showtime;";
	sql.executeSql(query, function (data, err) {
							if (err) {
															callback(err, null);
							}
						 else {
															callback(null, data);
							}
						});
}
exports.getshow=function(callback){
var query="SELECT th.theatre_showtime_id,t.t_name,m.movie_name,s.showtime,LEFT(th.datestart_from,10),LEFT(th.date_end,10) FROM theater_showtime th  join movie m join  theater t  join showtime s where m.movie_id=th.movie_id  and t.t_id=th.theater_id and s.show_id=th.show_id;";
sql.executeSql(query, function (data, err) {
						if (err) {
														callback(err, null);
						}
					 else {
														callback(null, data);
						}
					});
}
exports.addshow=function(theater_id,movie_id,show_id,datestart_from,date_end,callback){
	var query="INSERT INTO theater_showtime(theater_id, movie_id, show_id, datestart_from, date_end, createddate) VALUES ('"+theater_id+"','"+movie_id+"','"+show_id+"','"+datestart_from+"','"+date_end+"',now())";
	sql.executeSql(query, function (data, err) {
							if (err) {
															callback(err, null);
							}
						 else {
															callback(null, data);
							}
						});
}
