var mysql =require('mysql');
var sql = require('../config/sql.js');
var connection = require('../config/database');
var connect = mysql.createConnection(connection.dbconfig)
	connect.connect(function(err){
	if(!err)
	console.log("done connection in theater");
	else
	console.log("error in connection");
	});
//================get theater details=============
exports.gettheater=function(callback)
{
	var query="select t.t_id,t.t_name,t.address,t.phoneno,c.city_name from theater t,city c where t.city_id=c.city_id and t.isdeleted=0;";
	sql.executeSql(query, function (data, err) {
							if (err) {
															callback(err, null);
							}
						 else {
															callback(null, data);
							}
						});

}
	exports.addtheater = function (t_name,address,phoneno,city,callback) {
  	console.log("in theater model");

              var query = "INSERT INTO theater(t_name,address,phoneno,city_id,createddate) VALUES('"+t_name+"','"+address+"','"+phoneno+"','"+ city + "',now()); " ;
  						console.log(query);
              sql.executeSql(query, function (data, err) {
                          if (err) {
                                          callback(err, null);
                          }
                         else {
                                          callback(null, data);
                          }
            });
  }
