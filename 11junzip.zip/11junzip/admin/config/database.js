var mysql = require('mysql');

exports.dbconfig = {
	host: 'localhost',
	user: 'root',
	password: 'root',
	database: 'movie'
}
