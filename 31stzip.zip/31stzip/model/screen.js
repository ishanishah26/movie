var mysql =require('mysql');
var sql = require('../config/sql.js');
var connection = require('../config/database');
var connect = mysql.createConnection(connection.dbconfig)
	connect.connect(function(err){
	if(!err)
	console.log("done connection in screen");
	else
	console.log("error in connection");
	});
exports.gettheaterdrop=function(callback){
	var query="SELECT t_id,t_name from theater;";
	sql.executeSql(query, function (data, err) {
							if (err) {
															callback(err, null);
							}
						 else {
															callback(null, data);
							}
						});
}
exports.getscreen=function(callback){
var query="select s.screen_id,s.screen_name,s.totalrows,s.no_ofseat_eachrow ,t.t_name from screen_master s,theater t where s.theater_id=t.t_id and s.isdeleted=0";
sql.executeSql(query, function (data, err) {
						if (err) {
														callback(err, null);
						}
					 else {
														callback(null, data);
						}
					});
}
exports.addscreen=function(screen_name,theater_id,totalrows,no_ofseat_eachrow,callback)
{
	var query="INSERT INTO screen_master (screen_name,theater_id,totalrows,no_ofseat_eachrow,createddate)VALUES('"+screen_name+"','"+theater_id+"','"+totalrows+"','"+no_ofseat_eachrow+"',now());";
	sql.executeSql(query, function (data, err) {
							if (err) {
															callback(err, null);
							}
						 else {
															callback(null, data);
							}
						});
}
