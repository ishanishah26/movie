var mysql =require('mysql');
var sql = require('../config/sql.js');
var connection = require('../config/database');
var connect = mysql.createConnection(connection.dbconfig)
	connect.connect(function(err){
	if(!err)
	console.log("done connection in movie");
	else
	console.log("error in connection");
	});

exports.getmovie= function(callback){
	var query = "SELECT movie_id,movie_name,r_date,duration from movie where isdeleted=0" ;
	sql.executeSql(query, function (data, err) {
							if (err) {
															callback(err, null);
							}
						 else {

															callback(null, data);
							}
});
}
exports.addmovie= function(movie,rdate,casting,director,duration,image,callback){
	var query="INSERT INTO movie(movie_name, r_date, casting, director, duration,image,createddate) VALUES ('"+movie+"','"+rdate+"','"+casting+"','"+director+"','"+duration+"','"+image+"',now());";
	sql.executeSql(query, function (data, err) {
							if (err) {
															callback(err, null);
							}
						 else {

															callback(null, data);
							}
	});


}
