var express = require('express');
var router = express.Router();
var home=require('../model/seatbooking.js');

router.get('/seat_select',function(req,res,next){
          console.log("Cookies1 :  ", req.cookies.bdate);
        res.render('booking');

});



















module.exports = router;
