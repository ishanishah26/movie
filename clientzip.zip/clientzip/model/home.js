var mysql =require('mysql');
var sql = require('../config/sql.js');
var connection = require('../config/database');
var connect = mysql.createConnection(connection.dbconfig)
	connect.connect(function(err){
	if(!err)
	console.log("done connection in home");
	else
	console.log("error in connection");
	});

exports.getmoviedrop=function(callback){
		var query="SELECT distinct(th.movie_id),m.movie_name from theater_showtime th join movie m where m.movie_id =th.movie_id  and th.datestart_from<=CURDATE() and th.date_end >=CURDATE();";
		sql.executeSql(query, function (data, err) {
								if (err) {
																callback(err, null);
								}
							 else {
																callback(null, data);
								}
							});
	}

exports.gettheater=function(movie_id,callback){
  var query="SELECT distinct(th.theater_id),LEFT(th.date_end,10) as date,t.t_name from theater_showtime th join theater t where th.theater_id =t.t_id and th.movie_id ='"+movie_id+"';";
  sql.executeSql(query, function (data, err) {
              if (err) {
                              callback(err, null);
              }
             else {
                              callback(null, data);
              }
            });
}
// exports.getshowtime=function(movie_id,theater_id,date,callback){
// 	var bookingdate= date;
// 	var theater_id=theater_id;
// 	var theater_id=theater_id.split("/");
// 	var tid=theater_id[0];
// 	//console.log(tid);
//   var query="SELECT LEFT(st.showtime,5)as showtime,th.t_name,th.address,m.movie_name,m.r_date,m.director,m.casting,m.duration FROM showtime st join theater_showtime ts join theater th join movie m  where ts.show_id = st.show_id and ts.theater_id=th.t_id and ts.movie_id=m.movie_id and ts.theater_id='"+tid+"' and ts.movie_id='"+movie_id+"';";
// 	//console.log(query);
// 	sql.executeSql(query, function (data, err) {
//               if (err) {
//                               callback(err, null);
//               }
//              else {
//                               callback(null, data);
//               }
//             });
// }
exports.getshowtime=function(movie_id,theater_id,date,callback){
	var bookingdate= date;
	//var query="SELECT m.movie_name,LEFT(m.r_date,10) as r_date,m.director,m.casting,m.duration,m.language FROM movie m where movie_id='"+movie_id+"';";
	//var query="SELECT ts.theatre_showtime_id, LEFT(st.showtime,5)as showtime,th.t_name,th.address,m.movie_name,m.r_date,m.director,m.casting,m.duration FROM showtime st join theater_showtime ts join theater th join movie m  where ts.show_id = st.show_id and ts.theater_id=th.t_id and ts.movie_id=m.movie_id and ts.theater_id='"+theater_id+"' and ts.movie_id='"+movie_id+"';";
	var query="SELECT group_concat(ts.theatre_showtime_id,'') as tshowtimeid, group_concat(LEFT(st.showtime,5),'') as showtime,th.t_name,th.address,m.movie_name,m.r_date,m.director,m.casting,m.duration,m.language FROM showtime st join theater_showtime ts join theater th join movie m  where ts.show_id = st.show_id and ts.theater_id=th.t_id and ts.movie_id=m.movie_id and ts.theater_id='"+theater_id+"'and ts.movie_id='"+movie_id+"' Group by th.t_name;";

	sql.executeSql(query, function (data,err) {
              if(err){

									            callback(err, null);
              }
             else {

                              callback(null, data);
              }
            });
}
exports.getshowdate = function(enddate,callback){
//	console.log(enddate);
	var query="select * from (select adddate('2016-06-01',t4.i*10000 + t3.i*1000 + t2.i*100 + t1.i*10 + t0.i) selected_date from (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t0, (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t1, (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t2, (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t3, (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t4) v where selected_date between CURDATE() and '"+enddate+"';"
	sql.executeSql(query, function (data, err) {
              if(err){
                              callback(err, null);
              }
             else {
                              callback(null, data);
              }
            });

}
