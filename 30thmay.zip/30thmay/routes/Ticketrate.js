var express = require('express');
var router = express.Router();
var ticketrate=require('../model/ticketrate.js');

//==============theater=====================
router.get('/ticketrate',function(req,res){
  res.render('ticketrate',{title:'Manage ticketrate'});
});

module.exports = router;
