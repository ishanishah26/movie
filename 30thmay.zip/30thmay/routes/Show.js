var express = require('express');
var router = express.Router();
var show=require('../model/show.js');
//==============movie=============
router.get('/show',function(req,res){
  res.render('show',{title:'Manage show'});
});

module.exports = router;
