var express = require('express');
var router = express.Router();
var theater=require('../model/theater.js');

//==============theater=====================
router.get('/theater',function(req,res){
  res.render('theater',{title:'Manage theater'});
});


router.get ('/gettheater',function(req,res){
  theater.gettheater(function(data,err){
    if(!err){
      var k =0;
      var l=0;
      // var aaData=[];
       //var iTotalDisplayRecords=[];
       var Json = [];
        for (i = 0; i < data.length; i++)
        {       //final
                 Json[i]= [data[i]['t_id'],
                 data[i]['t_name'],
                 data[i]['address'],
                 data[i]['phoneno'],
                 data[i]['city_name'],
                 '<a href="" class="editor_edit">Edit</a> / <a href=""  class="editor_remove">Delete</a>'];
        }
        res.json({data:Json});
    }
    else {

      res.send("something bad happened");
    }
  });
});

//=======================add theater=========
router.post('/addtheater',function(req,res){
  theater.addtheater(req.body.t_name,req.body.address,req.body.phoneno,req.body.city,function(data,err){
    if(!err){

        res.send("inserted");

    }
    else {
      res.send("something bad happened");
    }
  });
});
module.exports = router;
