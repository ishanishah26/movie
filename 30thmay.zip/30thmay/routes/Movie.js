var express = require('express');
var router = express.Router();
var movie=require('../model/movie.js');
//==============movie=============
router.get('/movie',function(req,res){
  res.render('movie',{title:'Manage movie'});
});
router.get ('/getmovie',function(req,res){
  movie.getmovie(function(data,err){
    if(!err){
      // var k =0;
      // var l=0;
      // var aaData=[];
       //var iTotalDisplayRecords=[];
       var Json = [];
        for (i = 0; i < data.length; i++)
        {       //final
                 Json[i]= [data[i]['movie_id'],
                 data[i]['movie_name'],
                 data[i]['r_date'],
                 data[i]['duration'],
                 '<a href="" class="editor_edit">Edit</a> / <a href=""  class="editor_remove">Delete</a>'];
        }
        res.json({data:Json});
    }
    else {

      res.send("something bad happened");
    }
  });
});



module.exports = router;
