var express = require('express');
var router = express.Router();
var admin=require('../model/admin.js');
//======================city============
router.get('/city',function(req,res){
  res.render('city',{title:'Manage city'});
});

router.get('/getcitydrop',function (req, res) {
    admin.getcity(function (data,err) {
      if(!err)
      {
        
        res.json({"all_city":data});
      }
      else {
        res.send("something bad happened");
      }

    });
});

router.get('/getcity', function (req, res) {
    admin.getcity(function (data,err) {
        if (!err) {
          var k =0;
          var l=0;
           var aaData=[];
           var iTotalDisplayRecords=[];
          //console.log(data);

          //var record = [];
          var Json = [];
          Json.iTotalDisplayRecords=data.length;
          //Json['iTotalDisplayRecords']=data.length ;
           for (i = 0; i < data.length; i++)
           {       //final
                    Json[i]= [data[i]['city_id'],
  				          data[i]['city_name'],
                    '<a href="" class="editor_edit">Edit</a> / <a href=""  class="editor_remove">Delete</a>'];

                  // aaData[i]=[data[i]['city_id'],
                  //   data[i]['city_name']];




                  //aaData[i]= data[i]['city_id'];
                  //aaData[i]= data[i]['city_name'];




            //  console.log(data[i]['city_id']);
            //  record[i] = data[i];
            // console.log(data[i]);
            //  json['aaData'][i]=[];
            //  json['aaData'][i]["city_id"]=data[i].city_id;
            // json['aaData'][i]["city_name"]=data[i].city_name;
            // json['aaData'][i]=[
            //   "city_id":data[i].city_id,
            //   "city_name":data[i].city_name
            // }
            //k++;
          }
          //Json.push(aaData);
            // console.log(record);
          //   var json = {
          //     "iTotalDisplayRecords" : data.length,
          //     "aaData" : record
          //   }
          //   console.log(json);

          //  //json=[aaData, iTotalDisplayRecords];
           //
          //    json=JSON.stringify(json);
             console.log(Json);

          //res.render('city',{title:'Manage city',city:data});
          res.json({data:Json});
          console.log("hi");
          //console.log(res);
          return;

          }
        else {
          console.log(err);
                    //  res.render('404');
                    res.send("something bad happened");
                      return;
        }
    });
});

router.post('/addcity',function(req,res,err){
  //console.log("in addcity");
  //console.log(req.body.city_name);
  admin.addcity(req.body.city_name,function(data,err){
    if(!err){
      res.send("inserted");
      return;
      }
      else {
        console.log(err);
      res.send("something bad happened");
      return;
    }
  });
});
router.post('/editcity',function(req,res,err){
  console.log("in edicity");
  ///console.log(req.body.city_name);
  admin.editcity(req.body.city_id,function(data,err){
    if(!err){
      res.send(data);
      return;
      }
      else {
        console.log(err);
      res.send("something bad happened");
      return;
    }
  });
});
router.post('/editsavecity',function(req,res,err){
  console.log("in editsavecity");
  ///console.log(req.body.city_name);
  admin.editsavecity(req.body.city_id,req.body.city_name,function(data,err){
    if(!err){
      res.send("updated");
      return;
      }
      else {
        console.log(err);
      res.send("something bad happened");
      return;
    }
  });
});

router.post('/deletecity',function (req,res,err){
  console.log("in deletecity");
  ///console.log(req.body.city_name);
  admin.deletecity(req.body.city_id,function(data,err){
    if(!err){
      res.send("deleted");
      return;
      }
      else {
        console.log(err);
      res.send("something bad happened");
      return;
    }
  });
});
module.exports = router;
