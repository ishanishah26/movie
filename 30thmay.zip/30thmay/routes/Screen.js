var express = require('express');
var router = express.Router();
var screen =require('../model/screen.js');
//==============movie=============
router.get('/screen',function(req,res){
  res.render('screen',{title:'Manage screen'});
});

router.get('/gettheaterdrop',function(req,res){
  screen.gettheaterdrop(function(data,err){
    if(!err)
    {
    res.json({"all_theater":data});
    }
    else {
      res.send("something bad happened");
    }
  });
});
router.get ('/getscreen',function(req,res){
  screen.getscreen(function(data,err){
    if(!err){

       var Json = [];
        for (i = 0; i < data.length; i++)
        {       //final
                 Json[i]= [data[i]['screen_id'],
                   data[i]['screen_name'],
                   data[i]['t_name'],
                   data[i]['totalrows'],
                   data[i]['no_ofseat_eachrow'],
                 '<a href="" class="editor_edit">Edit</a> / <a href=""  class="editor_remove">Delete</a>'];
        }
        res.json({data:Json});
    }
    else {
      console.log(err);
      res.send("something bad happened");
    }
  });
});
//============addscreen========
router.post('/addscreen',function(req,res){
  screen.addscreen(req.body.screen_name,req.body.theater_id,req.body.totalrows,req.body.no_ofseat_eachrow,function(data,err){
    if(!err){
      res.send("inserted");
      return;
      }
      else {
        console.log(err);
      res.send("something bad happened");
      return;
    }
  });
});
module.exports = router;
