var express = require('express');
var router = express.Router();
var showtime=require('../model/showtime.js');
//==============movie=============
router.get('/showtime',function(req,res){
  res.render('showtime',{title:'Manage showtime'});
});

router.get ('/getshowtime',function(req,res){
  showtime.getshowtime(function(data,err){
    if(!err){

       var Json = [];
        for (i = 0; i < data.length; i++)
        {       //final
                 Json[i]= [data[i]['show_id'],
                   data[i]['showtime'],
                 '<a href="" class="editor_edit">Edit</a> / <a href=""  class="editor_remove">Delete</a>'];
        }
        res.json({data:Json});
    }
    else {

      res.send("something bad happened");
    }
  });
});
//============addshow========
router.post('/addshowtime',function(req,res){
  showtime.addshowtime(req.body.showtime,function(data,err){
    if(!err){
      res.send("inserted");
      return;
      }
      else {
        console.log(err);
      res.send("something bad happened");
      return;
    }
  });
});

module.exports = router;
