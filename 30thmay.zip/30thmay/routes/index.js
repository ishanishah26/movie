var express = require('express');
var router = express.Router();

/* GET home page. */
// router.get('/', function(req, res, next) {
//   res.render('index', { title: 'Login', msg:'' });
// });
router.get('/', function(req, res, next) {
  res.render('index', { title: 'AdminLogin', msg:'' });
});

module.exports = router;
