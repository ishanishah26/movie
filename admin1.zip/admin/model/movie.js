var mysql =require('mysql');
var sql = require('../config/sql.js');
var connection = require('../config/database');
var connect = mysql.createConnection(connection.dbconfig)
	connect.connect(function(err){
	if(!err)
	console.log("done connection in movie");
	else
	console.log("error in connection");
	});
