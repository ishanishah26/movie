var mysql =require('mysql');
var sql = require('../config/sql.js');
var connection = require('../config/database');
var connect = mysql.createConnection(connection.dbconfig)
	connect.connect(function(err){
	if(!err)
	console.log("done connection in seatbooking");
	else
	console.log("error in connection");
	});


	exports.pattern=function(callback){
		var pattern=[];

		//pattern.push("[");
		for (i=0 ; i<=2; i++){
var str='';
			//pattern.push("'");
			for (j=0 ; j <=3; j++){
					str += 'a';
			}
			pattern.push(str);
			if(i!=2)
			{
	// pattern.push("'");
	// pattern.push(",");
	}
		}
	//pattern.push("]");
	console.log(pattern);

			var query="insert into temp (map)values('"+pattern+"');";
			sql.executeSql(query, function (data, err) {
									if (err) {
																	callback(err, null);
									}
								 else {
																	callback(null, data);
									}
								});
		}
