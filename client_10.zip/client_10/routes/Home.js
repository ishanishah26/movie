var express = require('express');
var router = express.Router();
var home=require('../model/home.js');
//==================available movie==================
router.get('/getmoviedrop',function(req,res){
home.getmoviedrop(function(data,err){
  if(!err)
  {
  res.json({"all_movie":data});
  }
  else {
    res.send("something bad happened");
  }
});
});
//----------------------theater for choosen movie-------------------
router.post('/gettheater',function(req,res,err){
home.gettheater(req.body.movie_id,function(data,err){
  if(!err)
  {
  res.json({"all_theater":data });
  }
  else {
    console.log(err);
    res.send("something bad happened");
  }
});
});
//---------------------------dates for movie & theater-------------------
router.post('/getshowdate',function(req,res,err){
  home.getshowdate(req.body.enddate,function(data,err){
    if(!err)
    {
    res.json({"data":data});
    }
    else {
      console.log(err);
      res.send("something bad happened");
    }
  });
});
//-----------------------theater showtime----------
router.post('/getshowtime',function(req,res,err){
home.getshowtime(req.body.movie_id,req.body.theater_id,req.body.date,function(data,err){
  var date=req.body.date;
  console.log(date);
  //res.cookie('bdate',date,{ maxAge: 900000 });
  //req.session.date=date;
  if(!err)
  {
    var date=req.body.date;
     data[0].date=date;
     res.render('getshowtime',{result:data});
    // console.log("Cookies :  ", req.cookies.bdate);
     //console.log("session:",req.session.date);
  //res.json({"data":data});
  }
  else {
    res.send("something bad happened");
  }
});
});



module.exports = router;
