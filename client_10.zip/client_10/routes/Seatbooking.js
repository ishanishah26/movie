var express = require('express');
var router = express.Router();
var home1=require('../model/seatbooking.js');

router.get('/seat_select',function(req,res,next){
        //  console.log("Cookies1 :  ", req.cookies.bdate);
        res.render('booking');

});


router.get('/pattern',function(req,res,next){

  home1.pattern(function(data,err){
    if(!err)
    {
    res.send("hello");
    }
    else {
      res.send("something bad happened");
    }
});
});
















module.exports = router;
