var mysql =require('mysql');
var sql = require('../config/sql.js');
var connection = require('../config/database');
var connect = mysql.createConnection(connection.dbconfig)
	connect.connect(function(err){
	if(!err)
	console.log("done connection in ticketrate");
	else
	console.log("error in connection");
	});
exports.getticketrate=function(callback)
{
	var query="SELECT t.screenclass_id, th.t_name, t.booking_rate, t.screen_class_name, t.seat_in_each_row, t.total_row  FROM ticket_rate_master t join theater th where t.theater_id= th.t_id and t.isdeleted=0;";
	sql.executeSql(query, function (data, err) {
							if (err) {
															callback(err, null);
							}
						 else {
															callback(null, data);
							}
						});

}
	exports.addticketrate = function (t_name,booking,className,row,total_row,callback) {
  //	console.log("in theater model");

              var query = "INSERT INTO ticket_rate_master(theater_id,booking_rate,screen_class_name,seat_in_each_row,total_row,createddate) VALUES('"+t_name+"','"+booking+"','"+className+"','"+ row + "','"+total_row+"',now()); " ;
  						console.log(query);
              sql.executeSql(query, function (data, err) {
                          if (err) {
                                          callback(err, null);
                          }
                         else {
                                          callback(null, data);
                          }
            });
  }
