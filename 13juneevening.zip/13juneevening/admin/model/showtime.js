var mysql =require('mysql');
var sql = require('../config/sql.js');
var connection = require('../config/database');
var connect = mysql.createConnection(connection.dbconfig)
	connect.connect(function(err){
	if(!err)
	console.log("done connection in showtime");
	else
	console.log("error in connection");
	});
exports.getshowtime= function(callback){
	var query = "SELECT show_id,showtime from showtime where isdeleted=0" ;
	sql.executeSql(query, function (data, err) {
							if (err) {
															callback(err, null);
							}
						 else {

															callback(null, data);
							}
});

}

//===========================add show======
exports.addshowtime=function(showtime,callback){

var query=	"INSERT INTO showtime(showtime,createddate) VALUES('"+showtime+"',now()); " ;
	sql.executeSql(query, function (data, err) {
							if (err) {
															callback(err, null);
							}
						 else {

															callback(null, data);
							}
});
}
