<!DOCTYPE html>
<html>
	<title>Datatable Demo1 | CoderExample</title>
	<head>
		
		<script type="text/javascript" language="javascript" src="js/jquery.js"></script>
		<script type="text/javascript" language="javascript" src="js/jquery.dataTables.js"></script>
		<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.11/css/jquery.dataTables.min.css">
		<script type="text/javascript" language="javascript" >

			jQuery(document).ready(function() {
				var otable = jQuery('#social-table1').dataTable({
									"bFilter": false,
									"bLengthChange": false,
									"bSort": false,
									"paging": true,
									"iDisplayLength": 10,
									"bProcessing": true,
									"bServerSide": true,
									"info": true,
									"serverSide": true,
									"ordering": false,
									"searching": true,
									//"scrollY":350,
									"sAjaxSource": "process.php",
									"oLanguage": {
										"sEmptyTable": "No Review founds in the system.",
										"sZeroRecords": "No Connected account to display",
										"sProcessing": "Loading..."
									},
									"fnPreDrawCallback": function (oSettings) {
										//logged_in_or_not();
										
									},
									"fnServerParams": function (aoData) {
										aoData.push({"name": "get_social_detail", "value": true});
									}		
						});
			} );
		</script>
	</head>
	<body>
		
		<div class="container">
			<table id="social-table1" class="tableMerchant">
				<thead>
					<tr>
						<th>Name</th>
						<th>Salary</th>
						<th>Age</th>
					</tr>
				</thead>
			</table>
		</div>
	</body>
</html>
