<?php
/* Database connection start */
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "ado_test";

$conn = mysqli_connect($servername, $username, $password, $dbname) or die("Connection failed: " . mysqli_connect_error());

/* Database connection end */


if(isset($_REQUEST['get_social_detail']))
{
$Json['aaData'] = array();
$sLimit = "";
   
    $sql = "Select * from employee WHERE 1=1 ";
    if( !empty($_REQUEST['sSearch'])){// if there is a search parameter, $requestData['search']['value'] contains search parameter
    $sql.=" AND ( employee_name LIKE '".$_REQUEST['sSearch']."%' ";    
    $sql.=" OR employee_salary LIKE '".$_REQUEST['sSearch']."%' ";

     $sql.=" OR employee_age LIKE '".$_REQUEST['sSearch']."%' )";
    }
     if ( isset( $_REQUEST['iDisplayStart'] ) && $_REQUEST['iDisplayLength'] != '-1' )
    {
            $sql.= " LIMIT ".$_REQUEST['iDisplayStart'].", ".$_REQUEST['iDisplayLength'];
    }
    //echo $sql;
 	$query=mysqli_query($conn,$sql);
			$k =0;
            while($Row = mysqli_fetch_array($query))
            {
				$Json['aaData'][$k][]= $Row['employee_name'];
				$Json['aaData'][$k][]= $Row['employee_salary'];
                $Json['aaData'][$k][]= $Row['employee_age'];
				$k++;
            }
        $Json['iTotalDisplayRecords'] = $k+1;
 		$Json['sEcho'] = $_REQUEST['sEcho'];
        echo json_encode($Json);
        exit;	
}

?>
