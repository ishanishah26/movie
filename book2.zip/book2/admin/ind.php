<?php
include('login.php'); 
if(isset($_SESSION['login_user'])){
header("location: movie.php");
}
?>
<html>
<head>
<title>Login</title>
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="main">

<div id="login">
<form action="" method="post">
<h1>SIGN IN</h1>

<label>UserName :</label>
<input id="name" name="username" class="inputs" placeholder="username" type="text" required>
<label>Password :</label>
<input id="password" name="password" class="inputs" placeholder="**********" type="password" required>

<input name="submit" type="submit" value=" Login ">
<span><?php echo $error; ?></span>
</form>
</div>
</div>

</body>
</html>