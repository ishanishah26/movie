<?php
session_start();// Starting Session
$connection = mysqli_connect("localhost", "root", "","book");
$user_check=$_SESSION['login_user'];
$ses_sql=mysqli_query( $connection,"select username from admin_login where username='$user_check'");
$row = mysqli_fetch_assoc($ses_sql);
$login_session =$row['username'];
if(!isset($login_session)){
	mysqli_close($connection); // Closing Connection
	header('Location: signin.php'); // Redirecting To Home Page
}
?>