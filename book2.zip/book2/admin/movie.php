<?php 
ob_start();
include "header.php";
include "connect.php";
include "session.php";
if(isset($_POST['b1']))
{

	$mn=$_POST['mn'];
	$rd=$_POST['datepicker'];
	$ac=$_POST['ac'];
	$di=$_POST['di'];
	$du=$_POST['du'];
	//$image=$_POST['fileToUpload']
	$target_dir ="../images/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$file1=$target_file;
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image


    /*$check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }

//Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}

if ($_FILES["fileToUpload"]["size"] > 500000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}*/ 
//Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
}else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]);
    } else {
        echo "Sorry, there was an error uploading your file.";
    }

	mysqli_query($connection,"insert into movie (movie_name,r_date,actor,director,time,image ) values ('$mn','$rd','$ac','$di','$du','$file1')");	
}
}
?>
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
  <script src="//code.jquery.com/jquery-1.10.2.js"></script>
  <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script>
  $(function() {
    $( "#datepicker" ).datepicker();
     dateFormat: "yy-mm-dd";
     var dateFormat = $( ".selector" ).datepicker( "option", "dateFormat" );
 	 $( "#datepicker" ).datepicker( "option", "dateFormat", "yy-mm-dd" );
 	 //var d=$("#datepicker").val();
  });
  </script>
<div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
 	<!--banner-->	
		     <div class="banner">
		    	<h2>
				<a href="#">Home</a>
				<i class="fa fa-angle-right"></i>
				<span>Manage movie</span>
				</h2>
		    </div>
		<!--//banner-->
 	 <!--faq-->
 	<div class="blank">
	

			<div class="blank-page" style='height=500; wight=500'>
				<form name="movie" method="post"  enctype="multipart/form-data">
					<center>
				<table>
					<tr>
						<td><label>Movie name</label></td>
						<td><input type="text" name="mn" required></td>
					</tr>
					<tr>
						<td><label>Release date </label></td>
						<td>
							 <input type="text" name="datepicker" id="datepicker" ></td>
					</tr>

					<tr>
						<td><label>Actor</label></td>
						<td><input type="text" name="ac" required></td>
					</tr>
					<tr>
						<td><label>Directors</label></td>
						<td><input type="text" name="di" required></td>
					</tr>
					<tr>
						<td><label>Duration</label></td>
						<td><input type="text" name="du" required></td>
					</tr>
					 <tr>
					<td>movie image:</td>
					<td><input type="file" name="fileToUpload"  id="fileToUpload"></td>
					</tr>
					<tr>
						<td colspan="2"><input type="submit" value="add" name="b1" class="btn btn-lg btn-primary">
					</tr>
				</table>

				<table width="70%" border="2">
        <tr> 
          <td><strong><font color="#000000">Movie image</font></strong></td>	
          <td><strong><font color="#000000">Movie name</font></strong></td>
          <td><strong><font color="#000000">Release date </font></strong></td>
          <td><strong><font color="#000000">Actor</font></strong></td>
          <td><strong><font color="#000000">Directors</font></strong></td>
          <td><strong><font color="#000000">Duration</font></strong></td>
          <td colspan="2"><strong><font color="#000000">select action</font></strong></td>
        </tr>
<?php
$arr=mysqli_query($connection,"select * from movie");

while($row = mysqli_fetch_array($arr))
{

?>
        <tr>
          <td><img hight="70px" width="60px" src="<?php echo $row[6]; ?>" alt=""></td> 
          <td><?php echo $row[1]; ?></td>
          <td><?php echo $row[2]; ?></td>
          <td><?php echo $row[3]; ?></td>
          <td><?php echo $row[4]; ?></td>
          <td><?php echo $row[5]; ?></td>
         <td>
        <a href="update.php?pid=<?php echo $row[0]; ?>" ><strong>Edit</strong></a> 
        </td><td>
        <a href="delete.php?pid=<?php echo $row[0];?>" onclick="return confirm('Are you sure?')"><strong>Delete</strong></a> 
         </td>
          
        </tr>
<?php
  }
?>
</center>
			</form>
	        </div>
	       </div>
	
	<!--//faq-->
		<!---->
<div class="copy">
            
		</div>
		</div>
		<div class="clearfix"> </div>
       </div>
     
<!---->
<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->
</body>
</html>
