<?php 
ob_start();
include "header.php";
include "connect.php";
include "session.php";
if(isset($_POST['screen']))
{
	//echo"hi";
$sn=$_POST['sn'];
$mn=$_POST['mn'];
$tn=$_POST['tn'];
$se=$_POST['se'];
$sh=$_POST['show'];

mysqli_query($connection,"insert into screen(screen_name,movie_id,th_id,seat,show_id) values ('$sn','$mn','$tn',
	'$se','$sh')");
}
?>
<div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
 	<!--banner-->	
		     <div class="banner">
		    	<h2>
				<!-- <a href="index.html">Home</a> -->
				<i class="fa fa-angle-right"></i>
				<span>Manage Screen</span>
				</h2>
		    </div>
		<!--//banner-->
 	 <!--faq-->
 	<div class="blank">
	

			<div class="blank-page" style='height=500; wight=500'>
				
	        	<form name="movie" method="post">
					<center>
				<table>
					<tr>
						<td><label>Screen name</label></td>
						<td><input type="text" name="sn" required></td>
					</tr>
					<tr>
						<td><label>Movie name</label></td>
						<?php

							$rs= mysqli_query($connection,"SELECT movie_id,movie_name FROM movie ORDER BY movie_id DESC;") or die(mysql_error());
							//$rs = mysqli_query($connection,$result) or die(mysqli_error());
							echo '<td>';
							echo '<select name="mn" required>';
							
							echo '<option value=" " selected="selected">Choose movie</option>';
							
							while($mv = mysqli_fetch_array($rs)){
											//echo '<option value="">'
										  echo '<option value="'.$mv[0].'">'.$mv[1].'</option>';
										}
							//mysqli_free_result($rs);
							echo "</select>";
							echo '</td>';
  						?>
				
					</tr>
					<tr>
						<td><label>Theater name</label></td>
						<?php

							$rs= mysqli_query($connection,"SELECT t_id,t_name FROM theater ORDER BY t_id DESC;") or die(mysql_error());
							echo '<td>';
							echo '<select name="tn" required>';
							echo '<option value=" " selected="selected">Choose theater</option>';
							while($th = mysqli_fetch_array($rs)){
											
										  echo '<option value="'.$th[0].'">'.$th[1].'</option>';
							}
							echo "</select>";
							echo '</td>';
 						 ?>
					</tr>
						<tr>
						<td><label>No of seats</label></td>
						<td><input type="text" name="se" required></td>
						</tr>
					<tr>
						<td><label>Show time</label></td>
						
						<?php
						
							$shw= mysqli_query($connection,"SELECT show_id,show_time FROM showtime ORDER BY show_id DESC;") or die(mysql_error());
							
							echo '<td>';
							echo '<select name="show" required>';
							echo '<option value=" " selected="selected">Choose time</option>';
							while($show1= mysqli_fetch_array($shw)){
											//echo '<option value="">'
										  echo '<option value="'.$show1[0].'">'.$show1[1].'</option>';
										}
							//mysqli_free_result($rs);
							echo '</select>';
							echo '</td>';
 					 		?>
			
					</tr>
					 
					<tr>
						<td colspan="2"><center>
							<input name="screen" type="submit" value="Add screen"  class="btn btn-lg btn-primary">
						</center>
					</td>
					</tr>
				</table>

			</br>
		</br>
				<table width="60%" border="2" >
        <tr> 
          <td><strong><font color="#000000">screen </font></strong></td>
          <td><strong><font color="#000000">movie</font></strong></td>
          <td><strong><font color="#000000">theater</font></strong></td>
          <td><strong><font color="#000000">no of seat</font></strong></td>
          <td><strong><font color="#000000">show time</font></strong></td>
          
          <td colspan="2"><strong><font color="#000000">select action</font></strong></td>
        </tr>
<?php
$arr=mysqli_query($connection,"SELECT s.screen_id,s.screen_name,m.movie_name,t.t_name,s.seat,sh.show_time from screen s,movie m ,theater t ,
showtime sh where s.movie_id=m.movie_id and s.th_id=t.t_id and s.show_id=sh.show_id ;");
while($row = mysqli_fetch_array($arr))
{
?>
        <tr> 
          <td><?php echo $row[1]; ?></td>
          <td><?php echo $row[2]; ?></td>
          <td><?php echo $row[3]; ?></td>
          <td><?php echo $row[4]; ?></td>
          <td><?php echo $row[5]; ?></td>
         <td>
        <a href="update.php?pid=<?php echo $row[0]; ?>" ><strong>Edit</strong></a> 
        </td>
        <td>
        <a href="delete.php?pid=<?php echo $row[0];?>" onclick="return confirm('Are you sure?')"><strong>Delete</strong></a> 
         </td>
          
        </tr>
<?php 
}
?>

				</table>
					</center>
				</form>



	        </div>
	       </div>
	
	<!--//faq-->
		<!---->
<div class="copy">
 
		</div>
		</div>
		<div class="clearfix"> </div>
       </div>
     
<!---->
<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->
</body>
</html>
