<?php 
ob_start();
include "header.php";
include "connect.php";
include "session.php";
if(isset($_POST['addcity']))
{
	$city=$_POST['t1'];
	mysqli_query($connection,"insert into city
		(city_name) values ('$city')");	
}
?>
<div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
 	<!--banner-->	
		     <div class="banner">
		    	<h2>
				<a href="index.html">Home</a>
				<i class="fa fa-angle-right"></i>
				<span>manage city</span>
				</h2>
		    </div>
		<!--//banner-->
 	 <!--faq-->
 	<div class="blank">
	

			<div class="blank-page" style='height=500; wight=500'>
				<form method="post">
					<center>
					<table>
						<tr><td>
					<lable>city name:</lable></td>
				<td>
	        	<input type="text" name="t1"></td>
	        	</tr>
				<tr><td colspan="2">
					<center>
	        	<input type="submit" value="Addcity" name="addcity" class="btn btn-lg btn-primary"> </td></center></tr>
	        </table>
	    </br>
	</br>
	        <table width="40%" border="2">
        <tr> 
          <td><strong><font color="#000000">city name</font></strong></td>
          
          <td colspan="2"><strong><font color="#000000">select action</font></strong></td>
        </tr>
<?php
$arr=mysqli_query($connection,"select * from city");

while($row = mysqli_fetch_array($arr))
{

?>
        <tr> 
          <td><?php echo $row[1]; ?></td>
 <td>
        <a href="update.php?pid=<?php echo $row[0]; ?>" ><strong>Edit</strong></a> 
        </td><td>
        <a href="delete.php?pid=<?php echo $row[0];?>" onclick="return confirm('Are you sure?')"><strong>Delete</strong></a> 
         </td>
          
        </tr>
<?php
  }
?>
	    </center>	
	        	</form>
	        </div>
	       </div>
	
	<!--//faq-->
		<!---->
		</div>
		<div class="clearfix"> </div>
       </div>
     
<!---->
<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->
</body>
</html>
