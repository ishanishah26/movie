<?php

$error=''; 
if (isset($_POST['submit'])) 
{
	if (empty($_POST['username']) || empty($_POST['password']))
	{
	$error = "Username or Password is invalid";
	}
	else
	{
	$username=$_POST['username'];
	$password=$_POST['password'];
	$conn= mysqli_connect("localhost", "root", "");
	// protect MySQL injection 
	$username = stripslashes($username);
	$password = stripslashes($password);
	$username = mysqli_real_escape_string($username);
	$password = mysqli_real_escape_string($password);

	$db = mysqli_select_db("movie", $conn);
	$query = mysqli_query("select * from login where password='$password' AND username='$username'", $conn);
	$rows = mysqli_num_rows($query);

	if ($rows == 1) 
	{	
		session_start(); 
		$_SESSION['login_user']=$username; // Initializing Session
		header("location: movie.php"); // Redirecting To Other Page
	} else 
	{
		$error = "Username or Password is invalid";
	}
mysqli_close($conn); 
	}
}
?>

 

