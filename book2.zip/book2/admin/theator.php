<?php 
ob_start();
include "header.php";
include "connect.php";
include "session.php";
if(isset($_POST['t1']))
{
	$tn=$_POST['tn'];
	$city=$_POST['city'];
	$address=$_POST['ad'];
	$ph=$_POST['ph'];
	mysqli_query($connection,"insert into theater(t_name,address,phoneno,city_id) values ('$tn',
		'$address','$ph','$city')");	
} 
?>
<div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
 	<!--banner-->	
		     <div class="banner">
		    	<h2>
				<a href="#">Home</a>
				<i class="fa fa-angle-right"></i>
				<span>Manage theater</span>
				</h2>
		    </div>
		<!--//banner-->
 	 <!--faq-->
 	<div class="blank">
	

			<div class="blank-page" style='height=500; wight=500'>
				<form name="movie" method="post">
					<center>
				<table>
					<tr>
						<td><label>Theater name</label></td>
						<td><input type="text" name="tn" required></td>
					</tr>
					<tr>
						<td><label>select city</label></td>
						<?php

$rs= mysqli_query($connection,"SELECT * FROM city") or die(mysql_error());
//$rs = mysqli_query($connection,$result) or die(mysqli_error());
echo '<td>';
echo '<select name="city">';
while($city = mysqli_fetch_array($rs)){
				//echo '<option value="">'
			  echo '<option value="'.$city['city_id'].'">'.$city['city_name'].'</option>';
			}
//mysqli_free_result($rs);
echo "</select>";

  ?>
					<td>
					</tr>
					<tr>
						<td><label>Address </label></td>
						<td><input type="text" name="ad" required></td>
					</tr>
					<tr>
						<td><label>Phoneno</label></td>
						<td><input type="text" name="ph" required></td>
					</tr>
					
					 
					<tr>
						<td colspan="2"><input type="submit" value="add" name="t1" class="btn btn-lg btn-primary">
					</tr>
				</table>

				<table width="60%" border="2">
        <tr> 
          <td><strong><font color="#000000">theator name</font></strong></td>
          <td><strong><font color="#000000">city </font></strong></td>
          <td><strong><font color="#000000">address</font></strong></td>
          <td><strong><font color="#000000">phoneno</font></strong></td>
          
          <td colspan="2"><strong><font color="#000000">select action</font></strong></td>
        </tr>
<?php
$arr=mysqli_query($connection,"select t.t_id,t.t_name,t.address,t.phoneno,c.city_name from theater t,city c where t.city_id=c.city_id");
while($row = mysqli_fetch_array($arr))
{
?>
        <tr> 
          <td><?php echo $row[1]; ?></td>
          <td><?php echo $row[4]; ?></td>
          <td><?php echo $row[2]; ?></td>
          <td><?php echo $row[3]; ?></td>
          
         <td>
        <a href="update.php?pid=<?php echo $row[0]; ?>" ><strong>Edit</strong></a> 
        </td>
        <td>
        <a href="delete.php?pid=<?php echo $row[0];?>" onclick="return confirm('Are you sure?')"><strong>Delete</strong></a> 
         </td>
          
        </tr>
<?php 
}
?>
</table>
</center>
			</form>
	        </div>
	       </div>
	
	<!--//faq-->
		<!---->
<div class="copy">
            
		</div>
		</div>
		<div class="clearfix"> </div>
       </div>
     
<!---->
<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->
</body>
</html>
