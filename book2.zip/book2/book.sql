-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 16, 2016 at 07:48 AM
-- Server version: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `book`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE IF NOT EXISTS `admin_login` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`username`, `password`) VALUES
('admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE IF NOT EXISTS `city` (
`city_id` int(50) NOT NULL,
  `city_name` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`city_id`, `city_name`) VALUES
(1, 'surat'),
(2, 'ahemedabad'),
(3, 'rajkot');

-- --------------------------------------------------------

--
-- Table structure for table `movie`
--

CREATE TABLE IF NOT EXISTS `movie` (
`movie_id` int(50) NOT NULL,
  `movie_name` varchar(100) NOT NULL,
  `r_date` date NOT NULL,
  `actor` varchar(100) NOT NULL,
  `director` varchar(50) NOT NULL,
  `time` varchar(50) NOT NULL,
  `image` varchar(1000) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `movie`
--

INSERT INTO `movie` (`movie_id`, `movie_name`, `r_date`, `actor`, `director`, `time`, `image`) VALUES
(1, 'airlift', '2016-01-29', 'akshay', 'xyz', '2hour30minute', '../images/al.jpg'),
(3, 'mastizade', '2016-01-22', 'tushar', 'xyz', '2hour', '../images/masti.jpg'),
(4, 'kya cool he hum', '2016-01-29', 'tushar', 'xyz', '2hour15minute', '../images/kkh.jpg'),
(5, 'love-shuda', '2016-02-05', 'priyanka', 'mr.agrawal', '2hour 30min', '../images/love-sshuda.jpg'),
(6, 'direct-ishq', '2016-02-05', 'aaliya bhatt', 'mr.patel', '2hours15minute', '../images/di.jpg'),
(7, 'concussion', '2016-02-19', 'johnsmith', 'smithbrothres', '2hour 30min', '../images/concussion.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `screen`
--

CREATE TABLE IF NOT EXISTS `screen` (
`screen_id` int(11) NOT NULL,
  `screen_name` varchar(100) NOT NULL,
  `movie_id` int(11) NOT NULL,
  `th_id` int(11) NOT NULL,
  `startdate` date NOT NULL,
  `seat` int(11) NOT NULL,
  `show_id` int(50) NOT NULL,
  `enddate` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `screen`
--

INSERT INTO `screen` (`screen_id`, `screen_name`, `movie_id`, `th_id`, `startdate`, `seat`, `show_id`, `enddate`) VALUES
(6, 'screen1', 1, 1, '2016-02-03', 80, 2, '2016-02-29'),
(7, 'screen2', 4, 4, '2016-02-02', 80, 1, '2016-02-29'),
(8, 'screen3', 1, 3, '2016-02-04', 80, 4, '2016-02-29'),
(9, 'screen1', 1, 1, '2016-02-04', 80, 10, '2016-02-29'),
(10, 'screen2', 3, 3, '2016-02-04', 80, 7, '2016-02-29'),
(11, 'screen2', 4, 3, '2016-02-05', 80, 8, '2016-02-29'),
(12, 'screen2', 3, 1, '2016-02-04', 80, 9, '2016-02-29'),
(14, 'screen10', 4, 3, '2016-02-01', 60, 6, '2016-02-29'),
(15, 'screen9', 5, 1, '2016-02-01', 80, 8, '2016-02-29');

-- --------------------------------------------------------

--
-- Table structure for table `seat`
--

CREATE TABLE IF NOT EXISTS `seat` (
  `screen_id` int(50) NOT NULL,
  `seat` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `userid` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seat`
--

INSERT INTO `seat` (`screen_id`, `seat`, `status`, `userid`) VALUES
(6, '10_8', 'booked', '1'),
(6, '10_9,10_10', 'booked', '1');

-- --------------------------------------------------------

--
-- Table structure for table `showtime`
--

CREATE TABLE IF NOT EXISTS `showtime` (
`show_id` int(11) NOT NULL,
  `show_time` varchar(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `showtime`
--

INSERT INTO `showtime` (`show_id`, `show_time`) VALUES
(1, '10am'),
(2, '9am'),
(3, '12:30pm'),
(4, '11am'),
(5, '3pm'),
(6, '4pm'),
(7, '5pm'),
(8, '7pm'),
(9, '8pm'),
(10, '9pm'),
(11, '10pm');

-- --------------------------------------------------------

--
-- Table structure for table `theater`
--

CREATE TABLE IF NOT EXISTS `theater` (
`t_id` int(50) NOT NULL,
  `t_name` varchar(100) NOT NULL,
  `address` varchar(100) DEFAULT NULL,
  `phoneno` varchar(100) DEFAULT NULL,
  `city_id` int(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `theater`
--

INSERT INTO `theater` (`t_id`, `t_name`, `address`, `phoneno`, `city_id`) VALUES
(1, 'pvr cinemas', 'vr mall', '456268', 1),
(3, 'rajhansh', 'piplod', '5546557', 1),
(4, 'cinepolish', 'adajan', '543566', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_reg`
--

CREATE TABLE IF NOT EXISTS `user_reg` (
  `gender` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
`userid` int(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_reg`
--

INSERT INTO `user_reg` (`gender`, `username`, `email`, `mobile`, `password`, `userid`) VALUES
('ms.', 'ishani', 'lanetteam.ishani@gmail.com', '9876543210', 'ishanishah', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `city`
--
ALTER TABLE `city`
 ADD PRIMARY KEY (`city_id`);

--
-- Indexes for table `movie`
--
ALTER TABLE `movie`
 ADD PRIMARY KEY (`movie_id`);

--
-- Indexes for table `screen`
--
ALTER TABLE `screen`
 ADD PRIMARY KEY (`screen_id`), ADD KEY `movie_id` (`movie_id`,`th_id`), ADD KEY `th_id` (`th_id`), ADD KEY `show_id` (`show_id`), ADD KEY `show_id_2` (`show_id`);

--
-- Indexes for table `showtime`
--
ALTER TABLE `showtime`
 ADD PRIMARY KEY (`show_id`);

--
-- Indexes for table `theater`
--
ALTER TABLE `theater`
 ADD PRIMARY KEY (`t_id`), ADD KEY `city_id` (`city_id`), ADD KEY `city_id_2` (`city_id`);

--
-- Indexes for table `user_reg`
--
ALTER TABLE `user_reg`
 ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
MODIFY `city_id` int(50) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `movie`
--
ALTER TABLE `movie`
MODIFY `movie_id` int(50) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `screen`
--
ALTER TABLE `screen`
MODIFY `screen_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `showtime`
--
ALTER TABLE `showtime`
MODIFY `show_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `theater`
--
ALTER TABLE `theater`
MODIFY `t_id` int(50) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `user_reg`
--
ALTER TABLE `user_reg`
MODIFY `userid` int(50) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `screen`
--
ALTER TABLE `screen`
ADD CONSTRAINT `screen_ibfk_1` FOREIGN KEY (`movie_id`) REFERENCES `movie` (`movie_id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `screen_ibfk_2` FOREIGN KEY (`th_id`) REFERENCES `theater` (`t_id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `screen_ibfk_3` FOREIGN KEY (`show_id`) REFERENCES `showtime` (`show_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `theater`
--
ALTER TABLE `theater`
ADD CONSTRAINT `fk` FOREIGN KEY (`city_id`) REFERENCES `city` (`city_id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
