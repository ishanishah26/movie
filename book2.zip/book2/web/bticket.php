<html>
<head>
<style>
.flat_ui {
    width: 970px;
    margin: 0 auto;
    padding: 0px 10px;
}


</style>
</head>
<div>
<ul>
                        <li class="title">K</li>
                                    <li class="seat" row="K" seat="1" seat_id="K1" amt="160">1</li>
                                    <li class="seat" row="K" seat="2" seat_id="K2" amt="160">2</li>
                                    <li class="seat" row="K" seat="3" seat_id="K3" amt="160">3</li>
                                    <li class="seat" row="K" seat="4" seat_id="K4" amt="160">4</li>
                                    <li class="seat" row="K" seat="5" seat_id="K5" amt="160">5</li>
                                    <li></li>
                                    <li class="seat" row="K" seat="6" seat_id="K6" amt="160">6</li>
                                    <li class="seat" row="K" seat="7" seat_id="K7" amt="160">7</li>
                                    <li class="seat" row="K" seat="8" seat_id="K8" amt="160">8</li>
                                    <li class="seat" row="K" seat="9" seat_id="K9" amt="160">9</li>
                                    <li class="seat" row="K" seat="10" seat_id="K10" amt="160">10</li>
                                    <li class="seat" row="K" seat="11" seat_id="K11" amt="160">11</li>
                                    <li class="seat" row="K" seat="12" seat_id="K12" amt="160">12</li>
                                    <li class="seat" row="K" seat="13" seat_id="K13" amt="160">13</li>
                                    <li class="seat" row="K" seat="14" seat_id="K14" amt="160">14</li>
                                    <li class="seat" row="K" seat="15" seat_id="K15" amt="160">15</li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li class="seat" row="K" seat="16" seat_id="K16" amt="160">16</li>
                                    <li class="seat" row="K" seat="17" seat_id="K17" amt="160">17</li>
                                    <li class="seat" row="K" seat="18" seat_id="K18" amt="160">18</li>
                                    <li></li>
                                    <li class="seat" row="K" seat="19" seat_id="K19" amt="160">19</li>
                                    <li class="seat" row="K" seat="20" seat_id="K20" amt="160">20</li>
                                    <li class="seat" row="K" seat="21" seat_id="K21" amt="160">21</li>
                                    <li class="seat" row="K" seat="22" seat_id="K22" amt="160">22</li>
                                    <li class="seat" row="K" seat="23" seat_id="K23" amt="160">23</li>
                                    <li></li>
                        <li class="title">K</li>
</ul>
</div>
</html>