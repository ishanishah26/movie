<?php
session_start();
if(session_destroy()) // Destroying All Sessions
{
echo "1";// Redirecting To Home Page
}
else
{
echo "0";
}
?>