<?php
ob_start();
include "header.php";
?>
<div class="main-banner">
		 <div class="banner col-md-8">
			<section class="slider">
				<div class="flexslider">
						<ul class="slides">
						<li>
							<img src="images/pic1.jpg" class="img-responsive" alt="" />
						</li>
						<li>
							<img src="images/pic2.jpg" class="img-responsive" alt="" />
						</li>
						<li>
							<img src="images/pic3.jpg" class="img-responsive" alt="" />
						</li>
						<li>
							<img src="images/pic4.jpg" class="img-responsive" alt="" />
						</li>
				  </ul>
				</div>
					</section>
				 <!-- FlexSlider -->
				 <script defer src="js/jquery.flexslider.js"></script>

				 <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
					<script type="text/javascript">
				$(function(){
				// SyntaxHighlighter.all();
				});
				$(window).load(function(){
				  $('.flexslider').flexslider({
					animation: "slide",
					start: function(slider){
					  $('body').removeClass('loading');
					}
				 });
				});
			 </script>
         </div>
		 <div class="col-md-4 banner-right">
			<h4>Instant Ticket Booking</h4>
			<div class="grid_3 grid_5">
				   <div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
			<ul id="myTab" class="nav nav-tabs" role="tablist">
			  <li role="presentation" class="active"><a href="#home" id="home-tab" role="tab" data-toggle="tab" aria-controls="home" aria-expanded="true">Movies</a></li>
			 <!-- <li role="presentation"><a href="#profile" role="tab" id="profile-tab" data-toggle="tab" aria-controls="profile" aria-expanded="false">Plays</a></li>
			  <li role="presentation"><a href="#profile" role="tab" id="profile-tab" data-toggle="tab" aria-controls="profile" aria-expanded="false">Events</a></li>
			  <li role="presentation"><a href="#profile" role="tab" id="profile-tab" data-toggle="tab" aria-controls="profile" aria-expanded="false">Sports</a></li> -->
			</ul>
			<div id="myTabContent" class="tab-content">
			  <div role="tabpanel" class="tab-pane fade in active" id="home" aria-labelledby="home-tab">				  
                    <div class="fleft">
                        <form name="f1" method="post" > 
                        	<!-- //?myVariable=".'<?PHP //urlencode($movie);?>'.">" -->
                        <span class="fleft mr20">Movies</span></label>
                        <!--<label><input type="radio">
                        <span class="fleft mr20">Cinemas</span></label> -->
                    
					

						<!--<option value="">Select Movie</option><optgroup label="Telugu"><option style="padding-left: 10px;" value="SILI">Siliguri</option></optgroup></select>
					<select class="list_of_movies"><option value="">Select date</option><optgroup label="Telugu"><option style="padding-left: 10px;" value="SILI"></option></optgroup></select> -->
					
					<?php

						include "conn.php";
							$shw= mysqli_query($conn,"SELECT movie_id,movie_name from movie ORDER BY movie_id DESC;") or die(mysql_error());
							echo '<select class="list_of_movies" name="movie" required>';
							echo '<option  style="padding-left: 10px;"  value="">Choose movie</option>';
							while($show1= mysqli_fetch_array($shw)){
											
								echo  '<option value='.$show1[0].'>'.$show1[1].'</option>';
								}
							echo '</select>';
						if(isset($_POST['search']))
								{
									$movie=$_POST['movie'];
								//echo $movie;
									if(isset($_POST['movie']))
									{
										header('location:search.php?movie='.$movie);
									}
								}
							
					
 					 		?>
 					 		
 					 <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
  <script src="//code.jquery.com/jquery-1.10.2.js"></script>
  <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script>
  $(function() {
    /*$( "#datepicker" ).datepicker();
     dateFormat: "yy-mm-dd";
     var dateFormat = $( ".selector" ).datepicker( "option", "dateFormat" );*/
 	 $( "#datepicker" ).datepicker( {minDate: 0, maxDate: "+6D", dateFormat: 'yy-mm-dd'});
  });
  </script>
						<p>Date: <input type="text"  name="date" id="datepicker"></p>
					<input type="submit"  name="search" value="search">
				</form>
			</div>
			  </div>
			</div>
		   </div>
		  </div>
		 </div>
		 <div class="clearfix"></div>
	</div>
	<div class="review-slider">
		<ul id="flexiselDemo1">
	<?php 
	$mov=mysqli_query($conn,"select * from movie  order by movie_id DESC limit 6");
	while($mrow = mysqli_fetch_array($mov))
	{
	?>
	<li>
	<a href="#"><img src="<?php echo $mrow[6]; ?>" alt=""/></a>
		<div class="slide-title"><h4><?PHP echo $mrow[1];?></h4> </div>
			<div class="date-city">
					<h5><?php echo $mrow[2];?></h5>
					<h6>Multi-city</h6>
					<div class="buy-tickets">
						<a href="search.php?movie=<?php echo $mrow[0]; ?>">BUY TICKETS</a>
					</div>
				</div>
			</li>
	<?php
	}
	?>
	</ui>
	<script type="text/javascript">
		$(window).load(function() {
			
		  $("#flexiselDemo1").flexisel({
				visibleItems: 5,
				animationSpeed: 1000,
				autoPlay: true,
				autoPlaySpeed: 3000,    		
				pauseOnHover: false,
				enableResponsiveBreakpoints: true,
				responsiveBreakpoints: { 
					portrait: { 
						changePoint:480,
						visibleItems: 2
					}, 
					landscape: { 
						changePoint:640,
						visibleItems: 3
					},
					tablet: { 
						changePoint:800,
						visibleItems: 4
					}
				}
			});
			});
		</script>
		<script type="text/javascript" src="js/jquery.flexisel.js"></script>	
	</div>

<?php //include "footer.php";
?>
