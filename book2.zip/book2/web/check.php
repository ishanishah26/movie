<?php 
echo "hi";
?>
 <?php
                        $error=""; 
                        if(isset($_REQUEST['signin']))
                        {
                            //echo "here123";
                            if (empty($_POST['email']) || empty($_POST['psw']))
                            {
                            $error = "Username or Password is invalid";
                            }
                            else
                            {
                            $username=$_POST['email'];
                            $password=$_POST['psw'];
                            $conn= mysqli_connect("localhost", "root", "","book");
                            // protect MySQL injection 
                            $username = stripslashes($username);
                            $password = stripslashes($password);
                            $username = mysql_real_escape_string($username);
                            $password = mysql_real_escape_string($password);

                            //$db = mysqli_select_db(, $conn);
                            $query = mysqli_query( $conn,"select * from user_reg where password='$password' AND email='$username'");
                            $rows = mysqli_num_rows($query);

                            if ($rows == 1) 
                            {   
                                session_start(); 
                                $_SESSION['email']=$username; // Initializing Session
                                header("location: index.php"); // Redirecting To Other Page
                            } else 
                            {
                                $error = "Username or Password is invalid";
                            }
                             mysqli_close($conn); 
                         }
}
                        ?>