<?php 
ob_start();
include "header.php";
include "conn.php";
$sid=$_REQUEST['sid'];
$array=NULL;
$a1=NULL;
$query=mysqli_query($conn,"select seat from seat where screen_id=".$sid);
$totalrow=mysqli_num_rows($query);
if($totalrow>0)
{
while($row=mysqli_fetch_row($query))
{
	
	$array[]= $row[0];

}
//print_r($array);

$a1=implode(",", $array);
//$a2[]=$a1;
//return $a1;
}
?>
<html>
<head>
<style>
.front{width: 300px;margin: 5px 32px 45px 32px;background-color: #f0f0f0; color: #666;text-align: center;padding: 3px;border-radius: 5px;} 
.booking-details {float: right;position: relative;width:200px;height: 450px; } 
.booking-details h3 {margin: 5px 5px 0 0;font-size: 16px;} 
.booking-details p{line-height:26px; font-size:16px; color:#999} 
.booking-details p span{color:#666} 
div.seatCharts-cell {color: #182C4E;height: 25px;width: 25px;line-height: 25px;margin: 3px;float: left;text-align: center;outline: none;font-size: 13px;} 
div.seatCharts-seat {color: #fff;cursor: pointer;-webkit-border-radius:5px;-moz-border-radius:5px;border-radius: 5px;} 
div.seatCharts-row {height: 35px;} 
div.seatCharts-seat.available {background-color: #B9DEA0;} 
div.seatCharts-seat.focused {background-color: #76B474;border: none;} 
div.seatCharts-seat.selected {background-color: #E6CAC4;} 
div.seatCharts-seat.unavailable {background-color: #472B34;cursor: not-allowed;} 
div.seatCharts-container {border-right: 1px dotted #adadad;width: 400px;padding: 20px;float: left;} 
div.seatCharts-legend {padding-left: 0px;position: absolute;bottom: 16px;} 
ul.seatCharts-legendList {padding-left: 0px;} 
.seatCharts-legendItem{float:left; width:90px;margin-top: 10px;line-height: 2;} 
span.seatCharts-legendDescription {margin-left: 5px;line-height: 30px;} 
.checkout-button {display: block;width:80px; height:24px; line-height:20px;margin: 10px auto;border:1px solid #999;font-size: 14px; cursor:pointer} 
#selected-seats {max-height: 150px;overflow-y: auto;overflow-x: none;width: 200px;} 
#selected-seats li{float:left; width:72px; height:26px; line-height:26px; border:1px solid #d3d3d3; background:#f7f7f7; margin:6px; font-size:14px; font-weight:bold; text-align:center} 
</style>
<script type="text/javascript" src="jquery2.2.js"></script> 
<script type="text/javascript" src="jquery.seat-charts.js"></script> 
<script type="text/javascript">

var price = 150; //price
$(document).ready(function() 
{
   var check_session;
		var str="chksession=true";
		jQuery.ajax({
				type: "POST",
				url: "sessionck.php",
				data: str,
				cache: false,
				success: function(res){
					if(res == "1") {
					alert('please login to process further');
					//$('#process').hide();
					//$('#myModal').modal('show');
					}
					
				}
		}); // session check ajax
		//return false;
    
	var $cart = $('#selected-seats'), //Sitting Area
	$counter = $('#counter'), //Votes
	$total = $('#total'); //Total money
	var c_item;
	var sc = $('#seat-map').seatCharts({
		map: [  //Seating chart
			'aaaaaaaaaa',
            'aaaaaaaaaa',
            '__________',
            'aaaaaaaaaa',
            'aaaaaaaaaa',
			'aaaaaaaaaa',
			'__________',
			'aaaaaaaaaa',
			'aaaaaaaaaa',
            'aaaaaaaaaa'
		],
		naming : {
			top : false,
			getLabel : function (character, row, column) {
				return column;
			}
		},
		legend : { //Definition legend
			node : $('#legend'),
			items : [
				[ 'a', 'available',   'Option' ],
				[ 'a', 'unavailable', 'Sold']
			]					
		},
		click: function () { //Click event
			if (this.status() == 'available') { //optional seat
				$('<li>R'+(this.settings.row+1)+' S'+this.settings.label+'</li>')
					.attr('id', 'cart-item-'+this.settings.id)
					.attr('ids',this.settings.id) //gettting seat id to send other page 
					.data('seatId', this.settings.id)
					.appendTo($cart);
					
						//alert(this.settings.row+1 +" "+ this.settings.label  );
						//alert(this.settings.id);
				

				$counter.text(sc.find('selected').length+1);
				$total.text(recalculateTotal(sc)+price);
							
				return 'selected';
			} else if (this.status() == 'selected') { //Checked
					//Update Number
					$counter.text(sc.find('selected').length-1);
					//update totalnum
					$total.text(recalculateTotal(sc)-price);
						
					//Delete reservation
					$('#cart-item-'+this.settings.id).remove();
					//optional
					return 'available';
			} else if (this.status() == 'unavailable') { //sold
				return 'unavailable';
			} else {
				return this.style();
			}
			//document.getelementbyId("temphidden").value=$cart;
		}

	});
	
		
		var b_seat=<?php echo json_encode($a1); ?>;
		//alert(b_seat);
		if(b_seat != null)
		{
		var b1_seat=b_seat.split(",");
//alert(b1_seat);
		for (var i =0 ;i< b1_seat.length ; i++) {
			//alert(b1_seat[i]);
		sc.get(b1_seat[i]).status('unavailable');
		}
	}
	//sc.get(['4_4','4_5','6_6','6_7','8_5','8_6','8_7','8_8', '10_1', '10_2']).status('unavailable');
 	
 	

	var citem=[];
	jQuery("#process").click(function() {
		//alert("test");
	jQuery("#selected-seats li").each(function(){
  	citem.push(jQuery(this).attr('ids'));

	});
		
		//alert(citem);
		var sid='<?php echo $_REQUEST['sid'];?>';
		$("#suceess").load('bookseat.php?sd='+sid+'&ci='+citem);
	//	windows.open("bookseat.php?sd="+sid+'&ci='+citem);
		//var response=document.getelementbyId("success");
		//response=response.innerHTML;
		//alert(response.innerHTML());

		//alert("hello");
		
    });


}); //document ready
//sum total money
function recalculateTotal(sc) {
	var total = 0;
	sc.find('selected').each(function () {
		total += price;
	});
return total;
};



</script>
</head>
<body>
<!-- <form name="f1" method="post"> -->
<div class="demo">
<?php 
$screen=$_REQUEST['sid'];
$arr=mysqli_query($conn,"SELECT s.screen_id,s.screen_name,m.movie_name,t.t_name,t.address,sh.show_time from 
screen s,movie m ,theater t , showtime sh where s.movie_id=m.movie_id and s.th_id=t.t_id and s.show_id=sh.show_id and s.screen_id=".$screen);
while($row = mysqli_fetch_array($arr))
{
?>
<table width="80%"><tr><td>
   		<div id="seat-map">
			<div class="front">SCREEN</div>					
		</div><td>
		<td>
		<!-- <div hid="mas"><h1>please login to process further</h1></div> -->
		<div class="booking-details">
			<p>Movie: <span><?php echo $row[2]; ?> </span></p>
			<p>theator:<span><?php echo $row[3]; ?></span></p>
			<p>Address:<span><?php echo $row[4]; ?></span></p>
			<p>screen:<span><?php echo $row[1]; ?></span></p>
			<p>Time: <span><?php echo $row[5]; ?></span></p>
			<!-- <input type="hidden" id="temphidden" name="hf"> -->
			<ul id="selected-seats"></ul>
			<p>Tickets: <span id="counter">0</span></p>
			<p>Total: <b><span id="total">0</span></b></p>
			<div id="process">		
			<button name="pro" id="process">process</button></div>
			<div id="suceess">  </div>
			<div id="legend"></div>
		</div>
	</td></tr>
		<div style="clear:both"></div>
	</table>
   </div>
<?php
  }
 ?>


 <!-- sc.get(['4_4','4_5','6_6','6_7','8_5','8_6','8_7','8_8', '10_1', '10_2']).status('unavailable'); -->
 <?php 
 //$name="Nikunj";
 //echo "<script>";
 	//echo "alert('hello');";
 	//echo "sc.get(['4_4']).status('unavailable');";
 //echo "</script>";
  ?>
<!-- </form> -->
</body>
<?php //include "footer.php";?>