<?php 
ob_start();
$sid=$_REQUEST['sd'];
$a1 = $_REQUEST['ci'];
$a=json_encode($a1);
include "conn.php";
/*session_start();
if(isset($_SESSION['userid']))
{
$userid=$_SESSION['userid'];
$q='insert into seat(screen_id,seat,status,userid) values("'.$sid.'",'.$a.',"booked",'.$userid.')';
if(mysqli_query($conn,$q))
{
	echo "success";
}
else
{
	echo "fail";
}
}
*/
session_start();
if (isset($_SESSION['userid'])) {
$userid=$_SESSION['userid'];
$q='insert into seat(screen_id,seat,status,userid) values("'.$sid.'",'.$a.',"booked",'.$userid.')';
if(mysqli_query($conn,$q))
{
	echo "ticket booked";
}
else
{
	echo "ticket not booked";
}	
}else
{
	echo "please login";
}

//echo "select seat from seat where screen_id=".$sid;
/*$query=mysqli_query($conn,"select seat from seat where screen_id=".$sid);
while($row=mysqli_fetch_row($query))
{
	//echo $row[0];
	$array[]= $row[0];

}
//print_r($array);
$a1=implode(",", $array);
return $a1;*/
?>