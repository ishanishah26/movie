<?php
include "style.css";
?>
<html>
<head>
<title>seat</title>
<style>
#navcontainer ul
{
margin: 0;
padding: 0;
list-style-type: none;
}

#navcontainer ul li { display: inline; }
.seatLayout .top{padding: 20px 0px 10px;}
 .top{padding: 20px 0px 10px;}
 .top ul{margin: 0px;padding: 0px;}
 .top ul li{float: left;width: 350px;padding-right: 10px;line-height: 22px;}
 .top ul li:last-of-type{padding-right: 0px;width: auto;}
 .top ul li h1{font-size: 11px;color: #878787;display: block;font-weight: 600;}
 .top ul li b{font-size: 14.5px;color: #5d5d5d;display: block;}
 .top ul li a{float: right;margin-top: -5px;}
 .filterBy{padding: 30px 0 10px;border-bottom: 1px solid #e8e8e8;height: 58px;}
 .filterBy ul{margin: 0px;padding: 0px;list-style-type: none;}
 .filterBy ul li{float: left;}
 .filterBy ul li:first-of-type label{float: left;}
 .filterBy ul li.center{width: 450px;text-align: center;}
 .filterBy ul li .btn{padding: 12px 55px 12px 15px;display: inline-block;margin-left: 20px;font-size: 14px;}
 .filterBy ul li .btn i{background: url('../images/common-sprite.png')no-repeat -60px -22px;}
 .filterBy ul li label{font-size: 13px;color: #868686;padding: 12px 15px 0 0px;}
 .filterBy ul li b{font-size: 16px;color: #5d5d5d;padding: 10px 0px 0 0px;display: inline-block;}
 .filterBy ul li .textBox{margin: 0px 25px 0 0;}
 .filterBy ul li .textBox ul li{float: none;}
 .filterBy ul li .textBox input{width: 110px;}
 .filterBy ul li .link{display: block;padding: 10px 13px 2px 0px;text-align: right;}
 .filterBy ul li:last-of-type{float: right;}
 .filterBy ul li .qtySelect{float: left;}
 .filterBy ul li .qtySelect label{float: left;}
 .filterBy ul li .qtySelect ol{float: left;}
 .filterBy ul li .qtySelect ol li{height: 36px;width: 36px;border: 1px solid #878787;border-radius: 100%;-webkit-border-radius: 180px;color: #5d5d5d;font-size: 13px;line-height: 34px;text-align: center;margin-left: 10px;cursor: pointer;font-weight: 600;}
 .filterBy ul li .qtySelect ol li:hover, .filterBy ul li .qtySelect ol li.sel{color: #fff;background-color: #eb883f;border-color: #eb883f;}
 .filterBy ul li ol li{}

 .movieNotes{text-align: center;margin-top: 12px;font-size: 12px;color: #f42121;font-weight: 600;}

 .seatList{text-align: center;position: relative;overflow-x: auto;white-space: nowrap;min-height: 350px;margin-top: 15px;}
 .seatList .lineCon{position: relative;}
 .seatList .line{border-bottom: 1px solid #e8e8e8;position: absolute;top: 40px;width: 99.8%;z-index:1;}
 .seatList .btnCon{margin: 0 auto;width: 250px;padding: 20px 0;}
 .seatList .btnCon.noBg{padding: 0px;position: relative;top: 21px;}
 .seatList .btnCon.noBg .label{background: none;padding-bottom: 0px;border: none;}
 .seatList .label{position: relative;z-index: 2;background-color: #fff;border-radius: 250px;font-size: 12px;color: #393939;font-weight: 600;padding: 12px 15px;display: inline-block;width: 250px;text-align: center;text-transform: uppercase;border: 1px solid #e8e8e8;}
 .seatList .title{font-size: 12px;color: #878787;text-align: center;position: relative;top: 1px;height: auto;min-width: 25px;vertical-align: top;font-weight: 600;}
 .seatList .true .title{vertical-align: bottom;top: 0px;}
 .seatList li{width: 16px;height: 15px;margin: 0 3px 5px 0;display: inline-block;}
 .seatList li.seat{background: url('../images/entertainment-sprite.png')no-repeat -107px -94px;display: inline-block;cursor: pointer;}
 .seatList .true li{margin: 0 2px 1px 0;border: 1px solid #fff;border-radius: 3px;width: 18px;height: 18px;font-size: 11px;color: #5d5d5d;font-weight: 600;line-height: 18px;}
 .seatList .true li.seat{background: none;border-color: #878787;}
 .seatList .true li.seat:hover{background: #ea8133;color: #fff;border-color: #ea8133;}
 .seatList li.booked{background: url('../images/entertainment-sprite.png')no-repeat -132px -94px;display: inline-block;cursor: pointer;}
 .seatList .true li.booked{border-color: #eaeaea;background: #eaeaea;color: #ccc;}
 .seatList .true li.booked:hover{background: #eaeaea;}
 .seatList li.sel{background: url('../images/entertainment-sprite.png')no-repeat -158px -94px;display: inline-block;cursor: pointer;}
 .seatList .true li.sel{border: 1px solid #ea8133;background: #ea8133;color: #fff;}
 .seatList .true li.sel:hover{border: 1px solid #ea8133;background: #ea8133;}
 .seatList .border{border-top: 30px solid #e8e8e8; border-left: 30px solid transparent; border-right: 30px solid transparent; height: 0;margin-bottom: 20px;}
 .seatList .black_layer{display: block;top: 0px;left: 0px;width: 100%;height: 100%;position:absolute;z-index:100;-moz-opacity:0.01;opacity:0.7;filter: alpha(opacity=1);background-color: #000;}


</style>
    </head>
    <body>
    <div id="navcontainer">
   <div class="seatList"><div class="black_layer" style="display: none;"></div>        <div ref_id="5" wstxnid="020216105512846" showseatno="true" class="true">
            <div class="lineCon">
                <div class="btnCon">
                    <div id="#navcontainer">
                    <div class="label">EXECUTIVE - <i class="rupyaINR">Rs</i>250</div>
                </div>
                <div class="line"></div>
            </div>
                    <ul>
                        <li class="title">XX</li>
                                    <li></li>
                                    <li class="booked">1</li>
                                    <li class="booked">2</li>
                                    <li class="booked">3</li>
                                    <li class="booked">4</li>
                                    <li class="booked">5</li>
                                    <li class="booked">6</li>
                                    <li class="booked">7</li>
                                    <li class="booked">8</li>
                                    <li class="booked">9</li>
                                    <li class="booked">10</li>
                                    <li class="booked">11</li>
                                    <li class="booked">12</li>
                                    <li></li>
                                    <li class="booked">13</li>
                                    <li class="booked">14</li>
                                    <li class="booked">15</li>
                                    <li class="booked">16</li>
                                    <li class="booked">17</li>
                                    <li class="booked">18</li>
                                    <li class="booked">19</li>
                                    <li class="booked">20</li>
                                    <li class="booked">21</li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li class="booked">22</li>
                                    <li class="booked">23</li>
                                    <li class="booked">24</li>
                                    <li class="booked">25</li>
                                    <li class="booked">26</li>
                                    <li class="booked">27</li>
                                    <li></li>
                        <li class="title">XX</li>
                    </ul>
                    <div class="clr"></div>
        </div>
        <div ref_id="6" wstxnid="020216105512846" showseatno="true" class="true">
            <div class="lineCon">
                <div class="btnCon">
                    <div class="label">GOLD - <i class="rupyaINR">Rs</i>160</div>
                </div>
                <div class="line"></div>
            </div>
                    <ul>
                        <li class="title">A</li>
                                    <li class="booked">1</li>
                                    <li class="booked">2</li>
                                    <li class="booked">3</li>
                                    <li class="booked">4</li>
                                    <li class="booked">5</li>
                                    <li></li>
                                    <li class="booked">6</li>
                                    <li class="booked">7</li>
                                    <li class="booked">8</li>
                                    <li class="booked">9</li>
                                    <li class="booked">10</li>
                                    <li class="booked">11</li>
                                    <li class="booked">12</li>
                                    <li class="booked">13</li>
                                    <li class="booked">14</li>
                                    <li class="booked">15</li>
                                    <li class="booked">16</li>
                                    <li class="booked">17</li>
                                    <li class="booked">18</li>
                                    <li class="booked">19</li>
                                    <li class="booked">20</li>
                                    <li class="booked">21</li>
                                    <li class="booked">22</li>
                                    <li class="booked">23</li>
                                    <li class="booked">24</li>
                                    <li class="booked">25</li>
                                    <li></li>
                                    <li class="booked">26</li>
                                    <li class="booked">27</li>
                                    <li class="booked">28</li>
                                    <li class="booked">29</li>
                                    <li class="booked">30</li>
                                    <li></li>
                        <li class="title">A</li>
                    </ul>
                    <div class="clr"></div>
                    <ul>
                        <li class="title">B</li>
                                    <li class="booked">1</li>
                                    <li class="booked">2</li>
                                    <li class="booked">3</li>
                                    <li class="booked">4</li>
                                    <li class="booked">5</li>
                                    <li></li>
                                    <li class="booked">6</li>
                                    <li class="booked">7</li>
                                    <li class="booked">8</li>
                                    <li class="booked">9</li>
                                    <li class="booked">10</li>
                                    <li class="booked">11</li>
                                    <li class="booked">12</li>
                                    <li class="booked">13</li>
                                    <li class="booked">14</li>
                                    <li class="booked">15</li>
                                    <li class="booked">16</li>
                                    <li class="booked">17</li>
                                    <li class="booked">18</li>
                                    <li class="booked">19</li>
                                    <li class="booked">20</li>
                                    <li class="booked">21</li>
                                    <li class="booked">22</li>
                                    <li class="booked">23</li>
                                    <li class="booked">24</li>
                                    <li class="booked">25</li>
                                    <li></li>
                                    <li class="booked">26</li>
                                    <li class="booked">27</li>
                                    <li class="booked">28</li>
                                    <li class="booked">29</li>
                                    <li class="booked">30</li>
                                    <li></li>
                        <li class="title">B</li>
                    </ul>
                    <div class="clr"></div>
                    <ul>
                        <li class="title">C</li>
                                    <li class="booked">1</li>
                                    <li class="booked">2</li>
                                    <li class="booked">3</li>
                                    <li class="booked">4</li>
                                    <li class="booked">5</li>
                                    <li></li>
                                    <li class="booked">6</li>
                                    <li class="booked">7</li>
                                    <li class="booked">8</li>
                                    <li class="booked">9</li>
                                    <li class="booked">10</li>
                                    <li class="booked">11</li>
                                    <li class="booked">12</li>
                                    <li class="booked">13</li>
                                    <li class="booked">14</li>
                                    <li class="booked">15</li>
                                    <li class="booked">16</li>
                                    <li class="booked">17</li>
                                    <li class="booked">18</li>
                                    <li class="booked">19</li>
                                    <li class="booked">20</li>
                                    <li class="booked">21</li>
                                    <li class="booked">22</li>
                                    <li class="booked">23</li>
                                    <li class="booked">24</li>
                                    <li class="booked">25</li>
                                    <li></li>
                                    <li class="booked">26</li>
                                    <li class="booked">27</li>
                                    <li class="booked">28</li>
                                    <li class="booked">29</li>
                                    <li class="booked">30</li>
                                    <li></li>
                        <li class="title">C</li>
                    </ul>
                    <div class="clr"></div>
                    <ul>
                        <li class="title">D</li>
                                    <li class="booked">1</li>
                                    <li class="booked">2</li>
                                    <li class="booked">3</li>
                                    <li class="booked">4</li>
                                    <li class="booked">5</li>
                                    <li></li>
                                    <li class="booked">6</li>
                                    <li class="booked">7</li>
                                    <li class="booked">8</li>
                                    <li class="booked">9</li>
                                    <li class="booked">10</li>
                                    <li class="booked">11</li>
                                    <li class="booked">12</li>
                                    <li class="booked">13</li>
                                    <li class="booked">14</li>
                                    <li class="booked">15</li>
                                    <li class="booked">16</li>
                                    <li class="booked">17</li>
                                    <li class="booked">18</li>
                                    <li class="booked">19</li>
                                    <li class="booked">20</li>
                                    <li class="booked">21</li>
                                    <li class="booked">22</li>
                                    <li class="booked">23</li>
                                    <li class="booked">24</li>
                                    <li class="booked">25</li>
                                    <li></li>
                                    <li class="booked">26</li>
                                    <li class="booked">27</li>
                                    <li class="booked">28</li>
                                    <li class="booked">29</li>
                                    <li class="booked">30</li>
                                    <li></li>
                        <li class="title">D</li>
                    </ul>
                    <div class="clr"></div>
                    <ul>
                        <li class="title">E</li>
                                    <li class="seat" row="E" seat="1" seat_id="E1" amt="160">1</li>
                                    <li class="seat" row="E" seat="2" seat_id="E2" amt="160">2</li>
                                    <li class="seat" row="E" seat="3" seat_id="E3" amt="160">3</li>
                                    <li class="seat" row="E" seat="4" seat_id="E4" amt="160">4</li>
                                    <li class="seat" row="E" seat="5" seat_id="E5" amt="160">5</li>
                                    <li></li>
                                    <li class="seat" row="E" seat="6" seat_id="E6" amt="160">6</li>
                                    <li class="seat" row="E" seat="7" seat_id="E7" amt="160">7</li>
                                    <li class="seat" row="E" seat="8" seat_id="E8" amt="160">8</li>
                                    <li class="seat" row="E" seat="9" seat_id="E9" amt="160">9</li>
                                    <li class="seat" row="E" seat="10" seat_id="E10" amt="160">10</li>
                                    <li class="seat" row="E" seat="11" seat_id="E11" amt="160">11</li>
                                    <li class="seat" row="E" seat="12" seat_id="E12" amt="160">12</li>
                                    <li class="seat" row="E" seat="13" seat_id="E13" amt="160">13</li>
                                    <li class="seat" row="E" seat="14" seat_id="E14" amt="160">14</li>
                                    <li class="seat" row="E" seat="15" seat_id="E15" amt="160">15</li>
                                    <li class="seat" row="E" seat="16" seat_id="E16" amt="160">16</li>
                                    <li class="seat" row="E" seat="17" seat_id="E17" amt="160">17</li>
                                    <li class="seat" row="E" seat="18" seat_id="E18" amt="160">18</li>
                                    <li class="seat" row="E" seat="19" seat_id="E19" amt="160">19</li>
                                    <li class="seat" row="E" seat="20" seat_id="E20" amt="160">20</li>
                                    <li class="seat" row="E" seat="21" seat_id="E21" amt="160">21</li>
                                    <li class="seat" row="E" seat="22" seat_id="E22" amt="160">22</li>
                                    <li class="seat" row="E" seat="23" seat_id="E23" amt="160">23</li>
                                    <li class="seat" row="E" seat="24" seat_id="E24" amt="160">24</li>
                                    <li class="seat" row="E" seat="25" seat_id="E25" amt="160">25</li>
                                    <li></li>
                                    <li class="seat" row="E" seat="26" seat_id="E26" amt="160">26</li>
                                    <li class="seat" row="E" seat="27" seat_id="E27" amt="160">27</li>
                                    <li class="seat" row="E" seat="28" seat_id="E28" amt="160">28</li>
                                    <li class="seat" row="E" seat="29" seat_id="E29" amt="160">29</li>
                                    <li class="seat" row="E" seat="30" seat_id="E30" amt="160">30</li>
                                    <li></li>
                        <li class="title">E</li>
                    </ul>
                    <div class="clr"></div>
                    <ul>
                        <li class="title">F</li>
                                    <li class="booked">1</li>
                                    <li class="booked">2</li>
                                    <li class="booked">3</li>
                                    <li class="booked">4</li>
                                    <li class="booked">5</li>
                                    <li></li>
                                    <li class="booked">6</li>
                                    <li class="booked">7</li>
                                    <li class="booked">8</li>
                                    <li class="booked">9</li>
                                    <li class="booked">10</li>
                                    <li class="booked">11</li>
                                    <li class="booked">12</li>
                                    <li class="booked">13</li>
                                    <li class="booked">14</li>
                                    <li class="booked">15</li>
                                    <li class="booked">16</li>
                                    <li class="booked">17</li>
                                    <li class="booked">18</li>
                                    <li class="booked">19</li>
                                    <li class="booked">20</li>
                                    <li class="booked">21</li>
                                    <li class="booked">22</li>
                                    <li class="booked">23</li>
                                    <li class="booked">24</li>
                                    <li class="booked">25</li>
                                    <li></li>
                                    <li class="booked">26</li>
                                    <li class="booked">27</li>
                                    <li class="booked">28</li>
                                    <li class="booked">29</li>
                                    <li class="booked">30</li>
                                    <li></li>
                        <li class="title">F</li>
                    </ul>
                    <div class="clr"></div>
                    <ul>
                        <li class="title">G</li>
                                    <li class="booked">1</li>
                                    <li class="booked">2</li>
                                    <li class="booked">3</li>
                                    <li class="booked">4</li>
                                    <li class="booked">5</li>
                                    <li></li>
                                    <li class="booked">6</li>
                                    <li class="booked">7</li>
                                    <li class="booked">8</li>
                                    <li class="booked">9</li>
                                    <li class="booked">10</li>
                                    <li class="booked">11</li>
                                    <li class="booked">12</li>
                                    <li class="booked">13</li>
                                    <li class="booked">14</li>
                                    <li class="booked">15</li>
                                    <li class="booked">16</li>
                                    <li class="booked">17</li>
                                    <li class="booked">18</li>
                                    <li class="booked">19</li>
                                    <li class="booked">20</li>
                                    <li class="booked">21</li>
                                    <li class="booked">22</li>
                                    <li class="booked">23</li>
                                    <li class="booked">24</li>
                                    <li class="booked">25</li>
                                    <li></li>
                                    <li class="booked">26</li>
                                    <li class="booked">27</li>
                                    <li class="booked">28</li>
                                    <li class="booked">29</li>
                                    <li class="booked">30</li>
                                    <li></li>
                        <li class="title">G</li>
                    </ul>
                    <div class="clr"></div>
                    <ul>
                        <li class="title">H</li>
                                    <li class="booked">1</li>
                                    <li class="booked">2</li>
                                    <li class="booked">3</li>
                                    <li class="booked">4</li>
                                    <li class="booked">5</li>
                                    <li></li>
                                    <li class="booked">6</li>
                                    <li class="booked">7</li>
                                    <li class="booked">8</li>
                                    <li class="booked">9</li>
                                    <li class="booked">10</li>
                                    <li class="booked">11</li>
                                    <li class="booked">12</li>
                                    <li class="booked">13</li>
                                    <li class="booked">14</li>
                                    <li class="booked">15</li>
                                    <li class="booked">16</li>
                                    <li class="booked">17</li>
                                    <li class="booked">18</li>
                                    <li class="booked">19</li>
                                    <li class="booked">20</li>
                                    <li class="booked">21</li>
                                    <li class="booked">22</li>
                                    <li class="booked">23</li>
                                    <li class="booked">24</li>
                                    <li class="booked">25</li>
                                    <li></li>
                                    <li class="booked">26</li>
                                    <li class="booked">27</li>
                                    <li class="booked">28</li>
                                    <li class="booked">29</li>
                                    <li class="booked">30</li>
                                    <li></li>
                        <li class="title">H</li>
                    </ul>
                    <div class="clr"></div>
                    <ul>
                        <li class="title">I</li>
                                    <li class="booked">1</li>
                                    <li class="booked">2</li>
                                    <li class="booked">3</li>
                                    <li class="booked">4</li>
                                    <li class="booked">5</li>
                                    <li></li>
                                    <li class="booked">6</li>
                                    <li class="booked">7</li>
                                    <li class="booked">8</li>
                                    <li class="booked">9</li>
                                    <li class="booked">10</li>
                                    <li class="booked">11</li>
                                    <li class="booked">12</li>
                                    <li class="booked">13</li>
                                    <li class="booked">14</li>
                                    <li class="booked">15</li>
                                    <li class="booked">16</li>
                                    <li class="booked">17</li>
                                    <li class="booked">18</li>
                                    <li class="booked">19</li>
                                    <li class="booked">20</li>
                                    <li class="booked">21</li>
                                    <li class="booked">22</li>
                                    <li class="booked">23</li>
                                    <li class="booked">24</li>
                                    <li class="booked">25</li>
                                    <li></li>
                                    <li class="booked">26</li>
                                    <li class="booked">27</li>
                                    <li class="booked">28</li>
                                    <li class="booked">29</li>
                                    <li class="booked">30</li>
                                    <li></li>
                        <li class="title">I</li>
                    </ul>
                    <div class="clr"></div>
                    <ul>
                        <li class="title">J</li>
                                    <li class="booked">1</li>
                                    <li class="booked">2</li>
                                    <li class="booked">3</li>
                                    <li class="booked">4</li>
                                    <li class="booked">5</li>
                                    <li></li>
                                    <li class="booked">6</li>
                                    <li class="booked">7</li>
                                    <li class="booked">8</li>
                                    <li class="booked">9</li>
                                    <li class="booked">10</li>
                                    <li class="booked">11</li>
                                    <li class="booked">12</li>
                                    <li class="booked">13</li>
                                    <li class="booked">14</li>
                                    <li class="booked">15</li>
                                    <li class="booked">16</li>
                                    <li class="booked">17</li>
                                    <li class="booked">18</li>
                                    <li class="booked">19</li>
                                    <li class="booked">20</li>
                                    <li class="booked">21</li>
                                    <li class="booked">22</li>
                                    <li class="booked">23</li>
                                    <li class="booked">24</li>
                                    <li class="booked">25</li>
                                    <li></li>
                                    <li class="booked">26</li>
                                    <li class="booked">27</li>
                                    <li class="booked">28</li>
                                    <li class="booked">29</li>
                                    <li class="booked">30</li>
                                    <li></li>
                        <li class="title">J</li>
                    </ul>
                    <div class="clr"></div>
                    <ul>
                        <li class="title">K</li>
                                    <li class="seat" row="K" seat="1" seat_id="K1" amt="160">1</li>
                                    <li class="seat" row="K" seat="2" seat_id="K2" amt="160">2</li>
                                    <li class="seat" row="K" seat="3" seat_id="K3" amt="160">3</li>
                                    <li class="seat" row="K" seat="4" seat_id="K4" amt="160">4</li>
                                    <li class="seat" row="K" seat="5" seat_id="K5" amt="160">5</li>
                                    <li></li>
                                    <li class="seat" row="K" seat="6" seat_id="K6" amt="160">6</li>
                                    <li class="seat" row="K" seat="7" seat_id="K7" amt="160">7</li>
                                    <li class="seat" row="K" seat="8" seat_id="K8" amt="160">8</li>
                                    <li class="seat" row="K" seat="9" seat_id="K9" amt="160">9</li>
                                    <li class="seat" row="K" seat="10" seat_id="K10" amt="160">10</li>
                                    <li class="seat" row="K" seat="11" seat_id="K11" amt="160">11</li>
                                    <li class="seat" row="K" seat="12" seat_id="K12" amt="160">12</li>
                                    <li class="seat" row="K" seat="13" seat_id="K13" amt="160">13</li>
                                    <li class="seat" row="K" seat="14" seat_id="K14" amt="160">14</li>
                                    <li class="seat" row="K" seat="15" seat_id="K15" amt="160">15</li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li class="seat" row="K" seat="16" seat_id="K16" amt="160">16</li>
                                    <li class="seat" row="K" seat="17" seat_id="K17" amt="160">17</li>
                                    <li class="seat" row="K" seat="18" seat_id="K18" amt="160">18</li>
                                    <li></li>
                                    <li class="seat" row="K" seat="19" seat_id="K19" amt="160">19</li>
                                    <li class="seat" row="K" seat="20" seat_id="K20" amt="160">20</li>
                                    <li class="seat" row="K" seat="21" seat_id="K21" amt="160">21</li>
                                    <li class="seat" row="K" seat="22" seat_id="K22" amt="160">22</li>
                                    <li class="seat" row="K" seat="23" seat_id="K23" amt="160">23</li>
                                    <li></li>
                        <li class="title">K</li>
                    </ul>
                    <div class="clr"></div>
                    <ul>
                        <li class="title">L</li>
                                    <li class="seat" row="L" seat="1" seat_id="L1" amt="160">1</li>
                                    <li class="seat" row="L" seat="2" seat_id="L2" amt="160">2</li>
                                    <li class="seat" row="L" seat="3" seat_id="L3" amt="160">3</li>
                                    <li class="seat" row="L" seat="4" seat_id="L4" amt="160">4</li>
                                    <li class="seat" row="L" seat="5" seat_id="L5" amt="160">5</li>
                                    <li></li>
                                    <li class="seat" row="L" seat="6" seat_id="L6" amt="160">6</li>
                                    <li class="seat" row="L" seat="7" seat_id="L7" amt="160">7</li>
                                    <li class="seat" row="L" seat="8" seat_id="L8" amt="160">8</li>
                                    <li class="seat" row="L" seat="9" seat_id="L9" amt="160">9</li>
                                    <li class="seat" row="L" seat="10" seat_id="L10" amt="160">10</li>
                                    <li class="seat" row="L" seat="11" seat_id="L11" amt="160">11</li>
                                    <li class="seat" row="L" seat="12" seat_id="L12" amt="160">12</li>
                                    <li class="seat" row="L" seat="13" seat_id="L13" amt="160">13</li>
                                    <li class="seat" row="L" seat="14" seat_id="L14" amt="160">14</li>
                                    <li class="seat" row="L" seat="15" seat_id="L15" amt="160">15</li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li class="seat" row="L" seat="16" seat_id="L16" amt="160">16</li>
                                    <li class="seat" row="L" seat="17" seat_id="L17" amt="160">17</li>
                                    <li class="seat" row="L" seat="18" seat_id="L18" amt="160">18</li>
                                    <li></li>
                                    <li class="seat" row="L" seat="19" seat_id="L19" amt="160">19</li>
                                    <li class="seat" row="L" seat="20" seat_id="L20" amt="160">20</li>
                                    <li class="seat" row="L" seat="21" seat_id="L21" amt="160">21</li>
                                    <li class="seat" row="L" seat="22" seat_id="L22" amt="160">22</li>
                                    <li class="seat" row="L" seat="23" seat_id="L23" amt="160">23</li>
                                    <li></li>
                        <li class="title">L</li>
                    </ul>
                    <div class="clr"></div>
                    <ul>
                        <li class="title">M</li>
                                    <li class="seat" row="M" seat="1" seat_id="M1" amt="160">1</li>
                                    <li class="seat" row="M" seat="2" seat_id="M2" amt="160">2</li>
                                    <li class="seat" row="M" seat="3" seat_id="M3" amt="160">3</li>
                                    <li class="seat" row="M" seat="4" seat_id="M4" amt="160">4</li>
                                    <li class="seat" row="M" seat="5" seat_id="M5" amt="160">5</li>
                                    <li></li>
                                    <li class="seat" row="M" seat="6" seat_id="M6" amt="160">6</li>
                                    <li class="seat" row="M" seat="7" seat_id="M7" amt="160">7</li>
                                    <li class="seat" row="M" seat="8" seat_id="M8" amt="160">8</li>
                                    <li class="seat" row="M" seat="9" seat_id="M9" amt="160">9</li>
                                    <li class="seat" row="M" seat="10" seat_id="M10" amt="160">10</li>
                                    <li class="seat" row="M" seat="11" seat_id="M11" amt="160">11</li>
                                    <li class="seat" row="M" seat="12" seat_id="M12" amt="160">12</li>
                                    <li class="seat" row="M" seat="13" seat_id="M13" amt="160">13</li>
                                    <li class="seat" row="M" seat="14" seat_id="M14" amt="160">14</li>
                                    <li class="seat" row="M" seat="15" seat_id="M15" amt="160">15</li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li class="seat" row="M" seat="16" seat_id="M16" amt="160">16</li>
                                    <li class="seat" row="M" seat="17" seat_id="M17" amt="160">17</li>
                                    <li class="seat" row="M" seat="18" seat_id="M18" amt="160">18</li>
                                    <li></li>
                                    <li class="seat" row="M" seat="19" seat_id="M19" amt="160">19</li>
                                    <li class="seat" row="M" seat="20" seat_id="M20" amt="160">20</li>
                                    <li class="seat" row="M" seat="21" seat_id="M21" amt="160">21</li>
                                    <li class="seat" row="M" seat="22" seat_id="M22" amt="160">22</li>
                                    <li class="seat" row="M" seat="23" seat_id="M23" amt="160">23</li>
                                    <li></li>
                        <li class="title">M</li>
                    </ul>
                    <div class="clr"></div>
                    <ul>
                        <li class="title">N</li>
                                    <li class="seat" row="N" seat="1" seat_id="N1" amt="160">1</li>
                                    <li class="seat" row="N" seat="2" seat_id="N2" amt="160">2</li>
                                    <li class="seat" row="N" seat="3" seat_id="N3" amt="160">3</li>
                                    <li class="seat" row="N" seat="4" seat_id="N4" amt="160">4</li>
                                    <li class="seat" row="N" seat="5" seat_id="N5" amt="160">5</li>
                                    <li></li>
                                    <li class="seat" row="N" seat="6" seat_id="N6" amt="160">6</li>
                                    <li class="seat" row="N" seat="7" seat_id="N7" amt="160">7</li>
                                    <li class="seat" row="N" seat="8" seat_id="N8" amt="160">8</li>
                                    <li class="seat" row="N" seat="9" seat_id="N9" amt="160">9</li>
                                    <li class="seat" row="N" seat="10" seat_id="N10" amt="160">10</li>
                                    <li class="seat" row="N" seat="11" seat_id="N11" amt="160">11</li>
                                    <li class="seat" row="N" seat="12" seat_id="N12" amt="160">12</li>
                                    <li class="seat" row="N" seat="13" seat_id="N13" amt="160">13</li>
                                    <li class="seat" row="N" seat="14" seat_id="N14" amt="160">14</li>
                                    <li class="seat" row="N" seat="15" seat_id="N15" amt="160">15</li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li class="seat" row="N" seat="16" seat_id="N16" amt="160">16</li>
                                    <li class="seat" row="N" seat="17" seat_id="N17" amt="160">17</li>
                                    <li class="seat" row="N" seat="18" seat_id="N18" amt="160">18</li>
                                    <li></li>
                                    <li class="seat" row="N" seat="19" seat_id="N19" amt="160">19</li>
                                    <li class="seat" row="N" seat="20" seat_id="N20" amt="160">20</li>
                                    <li class="seat" row="N" seat="21" seat_id="N21" amt="160">21</li>
                                    <li class="seat" row="N" seat="22" seat_id="N22" amt="160">22</li>
                                    <li class="seat" row="N" seat="23" seat_id="N23" amt="160">23</li>
                                    <li></li>
                        <li class="title">N</li>
                    </ul>
                    <div class="clr"></div>
                    <ul>
                        <li class="title">O</li>
                                    <li class="seat" row="O" seat="1" seat_id="O1" amt="160">1</li>
                                    <li class="seat" row="O" seat="2" seat_id="O2" amt="160">2</li>
                                    <li class="seat" row="O" seat="3" seat_id="O3" amt="160">3</li>
                                    <li class="seat" row="O" seat="4" seat_id="O4" amt="160">4</li>
                                    <li class="seat" row="O" seat="5" seat_id="O5" amt="160">5</li>
                                    <li></li>
                                    <li class="seat" row="O" seat="6" seat_id="O6" amt="160">6</li>
                                    <li class="seat" row="O" seat="7" seat_id="O7" amt="160">7</li>
                                    <li class="seat" row="O" seat="8" seat_id="O8" amt="160">8</li>
                                    <li class="seat" row="O" seat="9" seat_id="O9" amt="160">9</li>
                                    <li class="seat" row="O" seat="10" seat_id="O10" amt="160">10</li>
                                    <li class="seat" row="O" seat="11" seat_id="O11" amt="160">11</li>
                                    <li class="seat" row="O" seat="12" seat_id="O12" amt="160">12</li>
                                    <li class="seat" row="O" seat="13" seat_id="O13" amt="160">13</li>
                                    <li class="seat" row="O" seat="14" seat_id="O14" amt="160">14</li>
                                    <li class="seat" row="O" seat="15" seat_id="O15" amt="160">15</li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li class="seat" row="O" seat="16" seat_id="O16" amt="160">16</li>
                                    <li class="seat" row="O" seat="17" seat_id="O17" amt="160">17</li>
                                    <li class="seat" row="O" seat="18" seat_id="O18" amt="160">18</li>
                                    <li></li>
                                    <li class="seat" row="O" seat="19" seat_id="O19" amt="160">19</li>
                                    <li class="seat" row="O" seat="20" seat_id="O20" amt="160">20</li>
                                    <li class="seat" row="O" seat="21" seat_id="O21" amt="160">21</li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                        <li class="title">O</li>
                    </ul>
                    <div class="clr"></div>
        </div>
        <div ref_id="7" wstxnid="020216105512846" showseatno="true" class="true">
            <div class="lineCon">
                <div class="btnCon">
                    <div class="label">GOLD STAR - <i class="rupyaINR">Rs</i>130</div>
                </div>
                <div class="line"></div>
            </div>
                    <ul>
                        <li class="title">P</li>
                                    <li class="booked">1</li>
                                    <li class="booked">2</li>
                                    <li class="booked">3</li>
                                    <li class="booked">4</li>
                                    <li class="booked">5</li>
                                    <li></li>
                                    <li class="booked">6</li>
                                    <li class="booked">7</li>
                                    <li class="booked">8</li>
                                    <li class="booked">9</li>
                                    <li class="booked">10</li>
                                    <li class="booked">11</li>
                                    <li class="booked">12</li>
                                    <li class="booked">13</li>
                                    <li class="booked">14</li>
                                    <li class="booked">15</li>
                                    <li class="booked">16</li>
                                    <li class="booked">17</li>
                                    <li class="booked">18</li>
                                    <li class="booked">19</li>
                                    <li class="booked">20</li>
                                    <li class="booked">21</li>
                                    <li class="booked">22</li>
                                    <li class="booked">23</li>
                                    <li class="booked">24</li>
                                    <li class="booked">25</li>
                                    <li></li>
                                    <li class="booked">26</li>
                                    <li class="booked">27</li>
                                    <li class="booked">28</li>
                                    <li class="booked">29</li>
                                    <li class="booked">30</li>
                                    <li></li>
                        <li class="title">P</li>
                    </ul>
                    <div class="clr"></div>
                    <ul>
                        <li class="title">Q</li>
                                    <li class="booked">1</li>
                                    <li class="booked">2</li>
                                    <li class="booked">3</li>
                                    <li class="booked">4</li>
                                    <li class="booked">5</li>
                                    <li></li>
                                    <li class="booked">6</li>
                                    <li class="booked">7</li>
                                    <li class="booked">8</li>
                                    <li class="booked">9</li>
                                    <li class="booked">10</li>
                                    <li class="booked">11</li>
                                    <li class="booked">12</li>
                                    <li class="booked">13</li>
                                    <li class="booked">14</li>
                                    <li class="booked">15</li>
                                    <li class="booked">16</li>
                                    <li class="booked">17</li>
                                    <li class="booked">18</li>
                                    <li class="booked">19</li>
                                    <li class="booked">20</li>
                                    <li class="booked">21</li>
                                    <li class="booked">22</li>
                                    <li class="booked">23</li>
                                    <li class="booked">24</li>
                                    <li class="booked">25</li>
                                    <li></li>
                                    <li class="booked">26</li>
                                    <li class="booked">27</li>
                                    <li class="booked">28</li>
                                    <li class="booked">29</li>
                                    <li class="booked">30</li>
                                    <li></li>
                        <li class="title">Q</li>
                    </ul>
                    <div class="clr"></div>
                    <ul>
                        <li class="title">R</li>
                                    <li class="booked">1</li>
                                    <li class="booked">2</li>
                                    <li class="booked">3</li>
                                    <li class="booked">4</li>
                                    <li class="booked">5</li>
                                    <li></li>
                                    <li class="booked">6</li>
                                    <li class="booked">7</li>
                                    <li class="booked">8</li>
                                    <li class="booked">9</li>
                                    <li class="booked">10</li>
                                    <li class="booked">11</li>
                                    <li class="booked">12</li>
                                    <li class="booked">13</li>
                                    <li class="booked">14</li>
                                    <li class="booked">15</li>
                                    <li class="booked">16</li>
                                    <li class="booked">17</li>
                                    <li class="booked">18</li>
                                    <li class="booked">19</li>
                                    <li class="booked">20</li>
                                    <li class="booked">21</li>
                                    <li class="booked">22</li>
                                    <li class="booked">23</li>
                                    <li class="booked">24</li>
                                    <li class="booked">25</li>
                                    <li></li>
                                    <li class="booked">26</li>
                                    <li class="booked">27</li>
                                    <li class="booked">28</li>
                                    <li class="booked">29</li>
                                    <li class="booked">30</li>
                                    <li></li>
                        <li class="title">R</li>
                    </ul>
                    <div class="clr"></div>
                    <ul>
                        <li class="title">S</li>
                                    <li class="booked">1</li>
                                    <li class="booked">2</li>
                                    <li class="booked">3</li>
                                    <li class="booked">4</li>
                                    <li class="booked">5</li>
                                    <li></li>
                                    <li class="booked">6</li>
                                    <li class="booked">7</li>
                                    <li class="booked">8</li>
                                    <li class="booked">9</li>
                                    <li class="booked">10</li>
                                    <li class="booked">11</li>
                                    <li class="booked">12</li>
                                    <li class="booked">13</li>
                                    <li class="booked">14</li>
                                    <li class="booked">15</li>
                                    <li class="booked">16</li>
                                    <li class="booked">17</li>
                                    <li class="booked">18</li>
                                    <li class="booked">19</li>
                                    <li class="booked">20</li>
                                    <li class="booked">21</li>
                                    <li class="booked">22</li>
                                    <li class="booked">23</li>
                                    <li class="booked">24</li>
                                    <li class="booked">25</li>
                                    <li></li>
                                    <li class="booked">26</li>
                                    <li class="booked">27</li>
                                    <li class="booked">28</li>
                                    <li class="booked">29</li>
                                    <li class="booked">30</li>
                                    <li></li>
                        <li class="title">S</li>
                    </ul>
                    <div class="clr"></div>
                    <ul>
                        <li class="title">T</li>
                                    <li class="booked">1</li>
                                    <li class="booked">2</li>
                                    <li class="booked">3</li>
                                    <li class="booked">4</li>
                                    <li class="booked">5</li>
                                    <li></li>
                                    <li class="booked">6</li>
                                    <li class="booked">7</li>
                                    <li class="booked">8</li>
                                    <li class="booked">9</li>
                                    <li class="booked">10</li>
                                    <li class="booked">11</li>
                                    <li class="booked">12</li>
                                    <li class="booked">13</li>
                                    <li class="booked">14</li>
                                    <li class="booked">15</li>
                                    <li class="booked">16</li>
                                    <li class="booked">17</li>
                                    <li class="booked">18</li>
                                    <li class="booked">19</li>
                                    <li class="booked">20</li>
                                    <li class="booked">21</li>
                                    <li class="booked">22</li>
                                    <li class="booked">23</li>
                                    <li class="booked">24</li>
                                    <li class="booked">25</li>
                                    <li></li>
                                    <li class="booked">26</li>
                                    <li class="booked">27</li>
                                    <li class="booked">28</li>
                                    <li class="booked">29</li>
                                    <li class="booked">30</li>
                                    <li></li>
                        <li class="title">T</li>
                    </ul>
                    <div class="clr"></div>
                    <ul>
                        <li class="title">U</li>
                                    <li class="booked">1</li>
                                    <li class="booked">2</li>
                                    <li class="booked">3</li>
                                    <li class="booked">4</li>
                                    <li class="booked">5</li>
                                    <li></li>
                                    <li class="booked">6</li>
                                    <li class="booked">7</li>
                                    <li class="booked">8</li>
                                    <li class="booked">9</li>
                                    <li class="booked">10</li>
                                    <li class="booked">11</li>
                                    <li class="booked">12</li>
                                    <li class="booked">13</li>
                                    <li class="booked">14</li>
                                    <li class="booked">15</li>
                                    <li class="booked">16</li>
                                    <li class="booked">17</li>
                                    <li class="booked">18</li>
                                    <li class="booked">19</li>
                                    <li class="booked">20</li>
                                    <li class="booked">21</li>
                                    <li class="booked">22</li>
                                    <li class="booked">23</li>
                                    <li class="booked">24</li>
                                    <li class="booked">25</li>
                                    <li></li>
                                    <li class="booked">26</li>
                                    <li class="booked">27</li>
                                    <li class="booked">28</li>
                                    <li class="booked">29</li>
                                    <li class="booked">30</li>
                                    <li></li>
                        <li class="title">U</li>
                    </ul>
                    <div class="clr"></div>
                    <ul>
                        <li class="title">V</li>
                                    <li class="seat" row="V" seat="1" seat_id="V1" amt="130">1</li>
                                    <li class="seat" row="V" seat="2" seat_id="V2" amt="130">2</li>
                                    <li class="seat" row="V" seat="3" seat_id="V3" amt="130">3</li>
                                    <li class="seat" row="V" seat="4" seat_id="V4" amt="130">4</li>
                                    <li class="seat" row="V" seat="5" seat_id="V5" amt="130">5</li>
                                    <li></li>
                                    <li class="seat" row="V" seat="6" seat_id="V6" amt="130">6</li>
                                    <li class="seat" row="V" seat="7" seat_id="V7" amt="130">7</li>
                                    <li class="seat" row="V" seat="8" seat_id="V8" amt="130">8</li>
                                    <li class="seat" row="V" seat="9" seat_id="V9" amt="130">9</li>
                                    <li class="seat" row="V" seat="10" seat_id="V10" amt="130">10</li>
                                    <li class="seat" row="V" seat="11" seat_id="V11" amt="130">11</li>
                                    <li class="seat" row="V" seat="12" seat_id="V12" amt="130">12</li>
                                    <li class="seat" row="V" seat="13" seat_id="V13" amt="130">13</li>
                                    <li class="seat" row="V" seat="14" seat_id="V14" amt="130">14</li>
                                    <li class="seat" row="V" seat="15" seat_id="V15" amt="130">15</li>
                                    <li class="seat" row="V" seat="16" seat_id="V16" amt="130">16</li>
                                    <li class="seat" row="V" seat="17" seat_id="V17" amt="130">17</li>
                                    <li class="seat" row="V" seat="18" seat_id="V18" amt="130">18</li>
                                    <li class="seat" row="V" seat="19" seat_id="V19" amt="130">19</li>
                                    <li class="seat" row="V" seat="20" seat_id="V20" amt="130">20</li>
                                    <li class="seat" row="V" seat="21" seat_id="V21" amt="130">21</li>
                                    <li class="seat" row="V" seat="22" seat_id="V22" amt="130">22</li>
                                    <li class="seat" row="V" seat="23" seat_id="V23" amt="130">23</li>
                                    <li class="seat" row="V" seat="24" seat_id="V24" amt="130">24</li>
                                    <li class="seat" row="V" seat="25" seat_id="V25" amt="130">25</li>
                                    <li></li>
                                    <li class="seat" row="V" seat="26" seat_id="V26" amt="130">26</li>
                                    <li class="seat" row="V" seat="27" seat_id="V27" amt="130">27</li>
                                    <li class="seat" row="V" seat="28" seat_id="V28" amt="130">28</li>
                                    <li class="seat" row="V" seat="29" seat_id="V29" amt="130">29</li>
                                    <li class="seat" row="V" seat="30" seat_id="V30" amt="130">30</li>
                                    <li></li>
                        <li class="title">V</li>
                    </ul>
                    <div class="clr"></div>
                    <ul>
                        <li class="title">W</li>
                                    <li class="seat" row="W" seat="1" seat_id="W1" amt="130">1</li>
                                    <li class="seat" row="W" seat="2" seat_id="W2" amt="130">2</li>
                                    <li class="seat" row="W" seat="3" seat_id="W3" amt="130">3</li>
                                    <li class="seat" row="W" seat="4" seat_id="W4" amt="130">4</li>
                                    <li class="seat" row="W" seat="5" seat_id="W5" amt="130">5</li>
                                    <li></li>
                                    <li class="seat" row="W" seat="6" seat_id="W6" amt="130">6</li>
                                    <li class="seat" row="W" seat="7" seat_id="W7" amt="130">7</li>
                                    <li class="seat" row="W" seat="8" seat_id="W8" amt="130">8</li>
                                    <li class="seat" row="W" seat="9" seat_id="W9" amt="130">9</li>
                                    <li class="seat" row="W" seat="10" seat_id="W10" amt="130">10</li>
                                    <li class="seat" row="W" seat="11" seat_id="W11" amt="130">11</li>
                                    <li class="seat" row="W" seat="12" seat_id="W12" amt="130">12</li>
                                    <li class="seat" row="W" seat="13" seat_id="W13" amt="130">13</li>
                                    <li class="seat" row="W" seat="14" seat_id="W14" amt="130">14</li>
                                    <li class="seat" row="W" seat="15" seat_id="W15" amt="130">15</li>
                                    <li class="seat" row="W" seat="16" seat_id="W16" amt="130">16</li>
                                    <li class="seat" row="W" seat="17" seat_id="W17" amt="130">17</li>
                                    <li class="seat" row="W" seat="18" seat_id="W18" amt="130">18</li>
                                    <li class="seat" row="W" seat="19" seat_id="W19" amt="130">19</li>
                                    <li class="seat" row="W" seat="20" seat_id="W20" amt="130">20</li>
                                    <li class="seat" row="W" seat="21" seat_id="W21" amt="130">21</li>
                                    <li class="seat" row="W" seat="22" seat_id="W22" amt="130">22</li>
                                    <li class="seat" row="W" seat="23" seat_id="W23" amt="130">23</li>
                                    <li class="seat" row="W" seat="24" seat_id="W24" amt="130">24</li>
                                    <li class="seat" row="W" seat="25" seat_id="W25" amt="130">25</li>
                                    <li></li>
                                    <li class="seat" row="W" seat="26" seat_id="W26" amt="130">26</li>
                                    <li class="seat" row="W" seat="27" seat_id="W27" amt="130">27</li>
                                    <li class="seat" row="W" seat="28" seat_id="W28" amt="130">28</li>
                                    <li class="seat" row="W" seat="29" seat_id="W29" amt="130">29</li>
                                    <li class="seat" row="W" seat="30" seat_id="W30" amt="130">30</li>
                                    <li></li>
                        <li class="title">W</li>
                    </ul>
                    <div class="clr"></div>
                    <ul>
                        <li class="title">X</li>
                                    <li class="seat" row="X" seat="1" seat_id="X1" amt="130">1</li>
                                    <li class="seat" row="X" seat="2" seat_id="X2" amt="130">2</li>
                                    <li class="seat" row="X" seat="3" seat_id="X3" amt="130">3</li>
                                    <li class="seat" row="X" seat="4" seat_id="X4" amt="130">4</li>
                                    <li class="seat" row="X" seat="5" seat_id="X5" amt="130">5</li>
                                    <li></li>
                                    <li class="seat" row="X" seat="6" seat_id="X6" amt="130">6</li>
                                    <li class="seat" row="X" seat="7" seat_id="X7" amt="130">7</li>
                                    <li class="seat" row="X" seat="8" seat_id="X8" amt="130">8</li>
                                    <li class="seat" row="X" seat="9" seat_id="X9" amt="130">9</li>
                                    <li class="seat" row="X" seat="10" seat_id="X10" amt="130">10</li>
                                    <li class="seat" row="X" seat="11" seat_id="X11" amt="130">11</li>
                                    <li class="seat" row="X" seat="12" seat_id="X12" amt="130">12</li>
                                    <li class="seat" row="X" seat="13" seat_id="X13" amt="130">13</li>
                                    <li class="seat" row="X" seat="14" seat_id="X14" amt="130">14</li>
                                    <li class="seat" row="X" seat="15" seat_id="X15" amt="130">15</li>
                                    <li class="seat" row="X" seat="16" seat_id="X16" amt="130">16</li>
                                    <li class="seat" row="X" seat="17" seat_id="X17" amt="130">17</li>
                                    <li class="seat" row="X" seat="18" seat_id="X18" amt="130">18</li>
                                    <li class="seat" row="X" seat="19" seat_id="X19" amt="130">19</li>
                                    <li class="seat" row="X" seat="20" seat_id="X20" amt="130">20</li>
                                    <li class="seat" row="X" seat="21" seat_id="X21" amt="130">21</li>
                                    <li class="seat" row="X" seat="22" seat_id="X22" amt="130">22</li>
                                    <li class="seat" row="X" seat="23" seat_id="X23" amt="130">23</li>
                                    <li class="seat" row="X" seat="24" seat_id="X24" amt="130">24</li>
                                    <li class="seat" row="X" seat="25" seat_id="X25" amt="130">25</li>
                                    <li></li>
                                    <li class="seat" row="X" seat="26" seat_id="X26" amt="130">26</li>
                                    <li class="seat" row="X" seat="27" seat_id="X27" amt="130">27</li>
                                    <li class="seat" row="X" seat="28" seat_id="X28" amt="130">28</li>
                                    <li class="seat" row="X" seat="29" seat_id="X29" amt="130">29</li>
                                    <li class="seat" row="X" seat="30" seat_id="X30" amt="130">30</li>
                                    <li></li>
                        <li class="title">X</li>
                    </ul>
                    <div class="clr"></div>
                    <ul>
                        <li class="title">Y</li>
                                    <li class="seat" row="Y" seat="1" seat_id="Y1" amt="130">1</li>
                                    <li class="seat" row="Y" seat="2" seat_id="Y2" amt="130">2</li>
                                    <li class="seat" row="Y" seat="3" seat_id="Y3" amt="130">3</li>
                                    <li class="seat" row="Y" seat="4" seat_id="Y4" amt="130">4</li>
                                    <li class="seat" row="Y" seat="5" seat_id="Y5" amt="130">5</li>
                                    <li></li>
                                    <li class="seat" row="Y" seat="6" seat_id="Y6" amt="130">6</li>
                                    <li class="seat" row="Y" seat="7" seat_id="Y7" amt="130">7</li>
                                    <li class="seat" row="Y" seat="8" seat_id="Y8" amt="130">8</li>
                                    <li class="seat" row="Y" seat="9" seat_id="Y9" amt="130">9</li>
                                    <li class="seat" row="Y" seat="10" seat_id="Y10" amt="130">10</li>
                                    <li class="seat" row="Y" seat="11" seat_id="Y11" amt="130">11</li>
                                    <li class="seat" row="Y" seat="12" seat_id="Y12" amt="130">12</li>
                                    <li class="seat" row="Y" seat="13" seat_id="Y13" amt="130">13</li>
                                    <li class="seat" row="Y" seat="14" seat_id="Y14" amt="130">14</li>
                                    <li class="seat" row="Y" seat="15" seat_id="Y15" amt="130">15</li>
                                    <li class="seat" row="Y" seat="16" seat_id="Y16" amt="130">16</li>
                                    <li class="seat" row="Y" seat="17" seat_id="Y17" amt="130">17</li>
                                    <li class="seat" row="Y" seat="18" seat_id="Y18" amt="130">18</li>
                                    <li class="seat" row="Y" seat="19" seat_id="Y19" amt="130">19</li>
                                    <li class="seat" row="Y" seat="20" seat_id="Y20" amt="130">20</li>
                                    <li class="seat" row="Y" seat="21" seat_id="Y21" amt="130">21</li>
                                    <li class="seat" row="Y" seat="22" seat_id="Y22" amt="130">22</li>
                                    <li class="seat" row="Y" seat="23" seat_id="Y23" amt="130">23</li>
                                    <li class="seat" row="Y" seat="24" seat_id="Y24" amt="130">24</li>
                                    <li class="seat" row="Y" seat="25" seat_id="Y25" amt="130">25</li>
                                    <li></li>
                                    <li class="seat" row="Y" seat="26" seat_id="Y26" amt="130">26</li>
                                    <li class="seat" row="Y" seat="27" seat_id="Y27" amt="130">27</li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                        <li class="title">Y</li>
                    </ul>
                    <div class="clr"></div>
        </div>
<div class="btnCon noBg">
    <div class="label">SCREEN HERE- Screen - 1</div>
</div>
<div class="clr"></div>
<div class="border"></div></div>
</div>
</html>