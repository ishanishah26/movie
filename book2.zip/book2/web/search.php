<?php
ob_start();
include "header.php";
$movie=$_REQUEST['movie'];
//echo $movie;
require "conn.php";
//mysqli_query($conn,"select * from screen where movie_id=".$movie);
?>
<center>
	
<h1>Movie details</h1>
	<?php $arr1=mysqli_query($conn,"select *from movie where movie_id=".$movie);
	 while($row1 = mysqli_fetch_array($arr1))
	{
	?>
        
         <table >
 		<tr>
 		<td><h3>Movie name:</h3></td>
 		<td><?php echo $row1[1]; ?></td>
 		</tr>
         <tr>
         <td><h3>Realese date:</h3></td>
         <td><?php echo $row1[2]; ?></td>
        </tr>
   	     <tr><td><h3>director:</h3></td>
   	      <td><?php echo $row1[4]; ?></td>
   	      </tr>
   	      
          <tr><td><h3>duration:</h3></td>
          <td><?php echo $row1[5]; ?></td>
          </tr>
          <tr>
   	      <td><h3>Cast and crew:</h3></td>
          <td><?php echo $row1[3]; ?></td>
          </tr>
   	      </table>
          <!-- <td><?php// echo $row[4]; ?></td>
          <td><?php //echo $row[6]; ?></td>
        -->
   <?php      
	 }
	 ?>
	</br>
	</br> 
	
	<h1>Available show</h1>
<table width="60%" >
        <tr> 
          <td><strong><font color="#000000">Screen </font></strong></td>
       
          <td><strong><font color="#000000">Theater</font></strong></td>
       	  <td><strong><font color="#000000">Location</font></strong></td>
          <td><strong><font color="#000000">Show time</font></strong></td>
          
          <td colspan="2"><strong><font color="#000000">select </font></strong></td>
        </tr>
<?php
$arr=mysqli_query($conn,"SELECT s.screen_id,s.screen_name,m.movie_name,t.t_name,t.address,s.seat,sh.show_time from screen s,movie m ,theater t ,
showtime sh where s.movie_id=m.movie_id and s.th_id=t.t_id and s.show_id=sh.show_id and s.movie_id=".$movie);
while($row = mysqli_fetch_array($arr))
{
?>
        <tr> 
          <td><?php echo $row[1]; ?></td>
          <td><?php echo $row[3]; ?></td>
       	  <td><?php echo $row[4]; ?></td>
          <td><?php echo $row[6]; ?></td>
         <td>
        <a href="jqdemo.php?sid=<?php echo $row[0]; ?>"><strong>select</strong></a> 
        </td>
        </tr>
        <tr>
        </tr>
<?php 
}
?>
<center>

