<?php 
include "conn.php";

if (empty($_REQUEST['user']) || empty($_REQUEST['ps']))
	{
	$error = "Username or Password is invalid";
	echo "$error";
	
	}
	else
	{
	$username=$_REQUEST['user'];
	$password=$_REQUEST['ps'];
	$conn= mysqli_connect("localhost", "root", "","book");
	// protect MySQL injection 
	$username = stripslashes($username);
	$password = stripslashes($password);
	$username = mysql_real_escape_string($username);
	$password = mysql_real_escape_string($password);

	//$db = mysqli_select_db(, $conn);
	//echo "select * from user_reg where password='$password' AND email='$username";
	$query = mysqli_query( $conn,"select * from user_reg where password='$password' AND email='$username'");
	/*while($rows = mysqli_num_rows($query)){
		//echo $rows[0];
		$usernm=$rows[1];
	}
    
    	*/
	$rows = mysqli_num_rows($query);
	
	
	if ($rows == 1) 
	{	
		while($row=mysqli_fetch_array($query)){
		$userid=$row[5];
		$usernm=$row[1];
		$email=$row[2];
		}
	
		session_start(); 
		$_SESSION['userid']=$userid;
		$_SESSION['usernm']= $usernm;
		$_SESSION['email']=$email;// Initializing Session
		echo "1";
		//echo $_SESSION['userid'];
		//return 1;
	}else 
	{ 

		$error = "Username or Password is invalid";
		echo "$error";
	}
mysqli_close($conn); 
	}
?>