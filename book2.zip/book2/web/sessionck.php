<?php
session_start();

//$_SESSION['username']="abc";
//$id = $_SESSION['userid'];
if( !isset($_SESSION["userid"]) ){
//session expired
	echo "1";
} 
else {
	//session not expired
    echo "0";
}

//print_r($_SESSION);
/*if($id == '')
{
	//session expired
	echo "1";
} else {
	//session not expired
    echo "0";
}*/
?>